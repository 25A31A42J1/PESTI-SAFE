import { Routes, Route, useLocation } from "react-router-dom"
import { useEffect } from "react"
import Navbar from "./components/Navbar.jsx"
import Footer from "./components/Footer.jsx"
import DemoBadge from "./components/DemoBadge.jsx"

import Landing from "./pages/Landing.jsx"
import Analyze from "./pages/Analyze.jsx"
import Results from "./pages/Results.jsx"
import Recovery from "./pages/Recovery.jsx"
import Dashboard from "./pages/Dashboard.jsx"
import RiskMap from "./pages/RiskMap.jsx"
import Prevention from "./pages/Prevention.jsx"
import Assistant from "./pages/Assistant.jsx"
import Settings from "./pages/Settings.jsx"
import NotFound from "./pages/NotFound.jsx"

function ScrollToTop() {
  const { pathname } = useLocation()
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "instant" })
  }, [pathname])
  return null
}

export default function App() {
  const { pathname } = useLocation()
  return (
    <div className="flex min-h-screen flex-col">
      <ScrollToTop />
      <Navbar />
      <main className="flex-1">
        <div key={pathname} className="animate-fade-in">
          <Routes>
            <Route path="/" element={<Landing />} />
            <Route path="/analyze" element={<Analyze />} />
            <Route path="/results" element={<Results />} />
            <Route path="/recovery" element={<Recovery />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/risk-map" element={<RiskMap />} />
            <Route path="/prevention" element={<Prevention />} />
            <Route path="/assistant" element={<Assistant />} />
            <Route path="/settings" element={<Settings />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </div>
      </main>
      <Footer />
      <DemoBadge />
    </div>
  )
}
