import { createContext, useContext, useState, useCallback, useMemo } from "react"
import { translations, languages } from "../data/translations.js"

const AppContext = createContext(null)

export function AppProvider({ children }) {
  const [lang, setLang] = useState("en")
  const [demoMode, setDemoMode] = useState(false)
  // Holds the latest analysis result so pages downstream can read it.
  const [analysis, setAnalysis] = useState(null)

  const t = useCallback(
    (key) => translations[lang]?.[key] ?? translations.en[key] ?? key,
    [lang],
  )

  const value = useMemo(
    () => ({ lang, setLang, languages, t, demoMode, setDemoMode, analysis, setAnalysis }),
    [lang, t, demoMode, analysis],
  )

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}

export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error("useApp must be used within AppProvider")
  return ctx
}

export function useTranslation() {
  return useApp().t
}
