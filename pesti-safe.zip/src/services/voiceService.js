// Voice + conversational assistant service.
// Speech recognition uses the browser Web Speech API when available, with a
// graceful text fallback. Assistant replies are rule-based mock logic for the
// prototype and can later be routed to a real LLM via VITE_VOICE_API_URL.

export function getSpeechRecognition() {
  if (typeof window === "undefined") return null
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition
  return SR ? new SR() : null
}

export function isSpeechSupported() {
  return !!getSpeechRecognition()
}

export function speak(text, lang = "en-US") {
  try {
    if (typeof window === "undefined" || !window.speechSynthesis) return
    const u = new SpeechSynthesisUtterance(text)
    u.lang = lang
    u.rate = 0.98
    window.speechSynthesis.cancel()
    window.speechSynthesis.speak(u)
  } catch {
    /* speech synthesis unavailable — silent fallback */
  }
}

// Simple agronomy-flavored conversational logic. Mock only.
export function getAssistantReply(message, history = []) {
  const text = message.toLowerCase()
  const askedWhen = history.some((m) => m.role === "assistant" && /when did you/i.test(m.text))
  const askedSpread = history.some((m) => m.role === "assistant" && /spreading/i.test(m.text))

  if (/(brown|spot|blight|yellow|wilt|curl|fungus|disease)/.test(text)) {
    if (!askedWhen) return "Thanks for describing that. When did you first notice the symptoms?"
    if (!askedSpread) return "Understood. Are the symptoms spreading to other leaves or plants?"
    return "This pattern can point to a fungal issue like early blight. I'd suggest starting with a low-risk biological treatment and removing badly affected leaves. Would you like me to open the full analysis and treatment plan?"
  }
  if (/(water|irrigat|dry|thirsty)/.test(text)) {
    return "For watering, I look at your crop, growth stage, soil moisture and the rain forecast. Open Smart Water Guidance and I'll estimate a safe amount for you."
  }
  if (/(weather|rain|humid|temperature)/.test(text)) {
    return "Weather matters a lot before treating. Rain within 24 hours usually means you should wait. Check Environmental Intelligence for the current window."
  }
  if (/(pesticide|chemical|spray|dose|dosage)/.test(text)) {
    return "I always suggest the least-harmful effective option first — biological and cultural controls. For any regulated chemical, please follow the product label and local guidance. I never invent dosages."
  }
  if (/(hi|hello|namaste|hey)/.test(text)) {
    return "Namaste! I'm your PestiSafe assistant. Tell me what you're seeing on your crop and I'll help you decide what to do."
  }
  return "Tell me a bit more — which crop is it, and what does the leaf or plant look like? You can also try Demo Mode to see a full example."
}

export const assistantStarters = [
  "My tomato leaves are turning brown.",
  "How much should I water my crop?",
  "Is it safe to spray before rain?",
  "What is the least harmful treatment?",
]
