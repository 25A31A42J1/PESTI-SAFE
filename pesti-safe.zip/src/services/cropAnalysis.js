// Crop analysis service.
// Currently returns MOCK data. The UI depends only on this interface, so a
// future vision model / API can be dropped in without touching components.
//
// To integrate a real model later:
//   const res = await fetch(import.meta.env.VITE_CROP_ANALYSIS_API_URL, {...})
//   return res.json()

import { demoCrop, scoreFactors, actionPlan } from "../data/demoData.js"

const delay = (ms) => new Promise((r) => setTimeout(r, ms))

// Mock image-quality assessment. Randomized so the flow feels real,
// but the demo case always passes.
export async function assessImageQuality(_file, { forceGood = false } = {}) {
  await delay(700)
  if (forceGood) return { ok: true, status: "good", message: "Image quality good" }
  const roll = Math.random()
  if (roll > 0.82) return { ok: false, status: "blurry", message: "Image may be blurry" }
  if (roll > 0.72) return { ok: false, status: "small", message: "Affected area is too small" }
  return { ok: true, status: "good", message: "Image quality good" }
}

export async function analyzeCrop(input = {}) {
  // Simulated latency for the scanning animation.
  await delay(2600)

  // Simulate an occasional AI-unavailable case unless we're in demo mode.
  if (!input.demo && input.simulateFailure) {
    throw new Error("AI analysis is temporarily unavailable. You can still use Demo Mode.")
  }

  // For the prototype, return the curated demo case merged with user input.
  return {
    ...demoCrop,
    crop: input.crop || demoCrop.crop,
    growthStage: input.growthStage || demoCrop.growthStage,
    location: input.location || demoCrop.location,
    scoreFactors,
    analyzedAt: new Date().toISOString(),
    isDemo: !!input.demo,
  }
}

export async function generateActionPlan(_result) {
  await delay(300)
  return actionPlan
}

// Mock second-image recovery comparison.
export async function compareRecovery(_beforeResult) {
  await delay(1200)
  const { recoveryData } = await import("../data/demoData.js")
  return recoveryData
}
