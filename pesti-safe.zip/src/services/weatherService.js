// Weather + water guidance service. Returns MOCK data for the prototype.
// Real integration: call a weather provider via VITE_WEATHER_API_URL and map
// the response into the same shape the UI already consumes.

import { weatherData, waterData } from "../data/demoData.js"

const delay = (ms) => new Promise((r) => setTimeout(r, ms))

export async function getWeather(_location) {
  await delay(500)
  return weatherData
}

export async function getWaterGuidance(_params) {
  await delay(500)
  return waterData
}
