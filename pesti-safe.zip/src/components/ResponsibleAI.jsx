import { ShieldCheck, AlertTriangle, BookOpen, FlaskConical } from "lucide-react"
import { useTranslation } from "../context/AppContext.jsx"
import { Card } from "./ui/Primitives.jsx"

const points = [
  { icon: AlertTriangle, text: "AI predictions may be uncertain — treat them as estimates." },
  { icon: BookOpen, text: "Low-confidence cases should be verified with an expert." },
  { icon: ShieldCheck, text: "Important agricultural decisions should follow local guidance." },
  { icon: FlaskConical, text: "Regulated products must always be used according to their labels." },
]

export default function ResponsibleAI({ compact = false }) {
  const t = useTranslation()
  return (
    <Card className={`p-6 sm:p-8 ${compact ? "" : "bg-gradient-to-br from-slate-50 to-white"}`}>
      <div className="flex items-center gap-2">
        <span className="grid h-9 w-9 place-items-center rounded-xl bg-brand-600 text-white">
          <ShieldCheck className="h-5 w-5" />
        </span>
        <h3 className="font-display text-xl font-extrabold text-slate-900">{t("responsible.title")}</h3>
      </div>
      <p className="mt-3 text-slate-600 font-medium">{t("responsible.main")}</p>
      <ul className="mt-5 grid gap-3 sm:grid-cols-2">
        {points.map((p, i) => (
          <li key={i} className="flex items-start gap-3 rounded-xl border border-slate-100 bg-white p-3">
            <p.icon className="mt-0.5 h-5 w-5 shrink-0 text-brand-600" />
            <span className="text-sm text-slate-600">{p.text}</span>
          </li>
        ))}
      </ul>
    </Card>
  )
}
