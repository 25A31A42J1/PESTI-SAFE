import { useEffect, useState } from "react"

// Animated circular crop-health score.
export default function HealthRing({ score = 0, size = 180, label = "Crop Health", severity }) {
  const [display, setDisplay] = useState(0)
  const stroke = 14
  const radius = (size - stroke) / 2
  const circ = 2 * Math.PI * radius

  useEffect(() => {
    let raf
    const start = performance.now()
    const duration = 1200
    const tick = (now) => {
      const p = Math.min(1, (now - start) / duration)
      const eased = 1 - Math.pow(1 - p, 3)
      setDisplay(Math.round(eased * score))
      if (p < 1) raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [score])

  const color = score >= 80 ? "#16a34a" : score >= 60 ? "#22c55e" : score >= 40 ? "#f59e0b" : "#ef4444"
  const offset = circ - (display / 100) * circ

  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke="#f1f5f9" strokeWidth={stroke} />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={circ}
          strokeDashoffset={offset}
          style={{ transition: "stroke-dashoffset 0.1s linear" }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="font-display text-4xl font-extrabold text-slate-900">{display}</span>
        <span className="text-xs font-medium text-slate-400">/ 100</span>
        {severity && (
          <span className="mt-1 text-sm font-semibold" style={{ color }}>
            {severity}
          </span>
        )}
      </div>
    </div>
  )
}
