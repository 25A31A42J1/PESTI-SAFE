import { useEffect, useState } from "react"
import { Thermometer, Droplets, CloudRain, Wind, Sprout, AlertTriangle, CloudSun } from "lucide-react"
import { Card, Badge } from "../ui/Primitives.jsx"
import { getWeather } from "../../services/weatherService.js"

const statusTone = {
  good: { tone: "brand", label: "Good conditions" },
  caution: { tone: "amber", label: "Reassess before acting" },
  avoid: { tone: "rose", label: "Avoid application" },
}

export default function Environmental() {
  const [w, setW] = useState(null)
  useEffect(() => {
    let active = true
    getWeather().then((d) => active && setW(d))
    return () => (active = false)
  }, [])

  if (!w) return <Card className="p-6 h-48 animate-pulse bg-slate-50" />

  const metrics = [
    { icon: Thermometer, label: "Temperature", value: `${w.temperature}°C`, tone: "amber" },
    { icon: Droplets, label: "Humidity", value: `${w.humidity}%`, tone: "blue" },
    { icon: CloudRain, label: "Rain Probability", value: `${w.rainProbability}%`, tone: "blue" },
    { icon: Wind, label: "Wind", value: `${w.wind} (${w.windSpeed} km/h)`, tone: "slate" },
    { icon: Sprout, label: "Soil Condition", value: w.soilCondition, tone: "brand" },
  ]
  const st = statusTone[w.status]

  return (
    <Card className="p-6 sm:p-8">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <Badge tone="blue" className="mb-2">
            <CloudSun className="h-3.5 w-3.5" /> Environmental Intelligence
          </Badge>
          <h3 className="font-display text-xl font-extrabold text-slate-900">Environmental conditions</h3>
        </div>
        {w.isMock && <Badge tone="slate">Demo weather data</Badge>}
      </div>

      <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        {metrics.map((m) => (
          <div key={m.label} className="rounded-xl border border-slate-100 bg-slate-50/60 p-4">
            <m.icon className={`h-5 w-5 ${m.tone === "blue" ? "text-sky-500" : m.tone === "amber" ? "text-amber-500" : m.tone === "brand" ? "text-brand-500" : "text-slate-400"}`} />
            <p className="mt-2 text-xs font-semibold uppercase tracking-wide text-slate-400">{m.label}</p>
            <p className="mt-0.5 font-bold text-slate-900">{m.value}</p>
          </div>
        ))}
      </div>

      <div
        className={`mt-6 flex items-start gap-3 rounded-xl px-4 py-4 ${
          st.tone === "brand" ? "bg-brand-50 text-brand-800" : st.tone === "amber" ? "bg-amber-50 text-amber-800" : "bg-rose-50 text-rose-800"
        }`}
      >
        <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0" />
        <div>
          <p className="font-bold">{st.label}</p>
          <p className="mt-0.5 text-sm">{w.decision}</p>
        </div>
      </div>
    </Card>
  )
}
