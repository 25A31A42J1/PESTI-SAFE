import { useEffect, useState } from "react"
import { Droplets, Waves } from "lucide-react"
import { Card, Badge, Disclosure } from "../ui/Primitives.jsx"
import { getWaterGuidance } from "../../services/weatherService.js"

export default function WaterGuidance() {
  const [data, setData] = useState(null)
  const [fill, setFill] = useState(0)

  useEffect(() => {
    let active = true
    getWaterGuidance().then((d) => {
      if (!active) return
      setData(d)
      setTimeout(() => setFill(d.needLevel), 200)
    })
    return () => (active = false)
  }, [])

  if (!data) return <Card className="p-6 h-48 animate-pulse bg-slate-50" />

  const segments = 10
  const filled = Math.round((data.needLevel / 100) * segments)

  return (
    <Card className="p-6 sm:p-8">
      <Badge tone="blue" className="mb-2">
        <Waves className="h-3.5 w-3.5" /> Smart Water Guidance
      </Badge>
      <h3 className="font-display text-xl font-extrabold text-slate-900">Estimated water requirement</h3>
      <p className="mt-1 text-slate-500">
        Based on crop, growth stage, soil condition, irrigation method and current conditions.
      </p>

      <div className="mt-6 grid gap-6 sm:grid-cols-2">
        <div className="rounded-2xl bg-gradient-to-br from-sky-50 to-white p-5">
          <div className="flex items-end justify-between">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">Water need</p>
              <p className="font-display text-3xl font-extrabold text-sky-600">{data.recommendation}</p>
            </div>
            <Droplets className="h-8 w-8 text-sky-400" />
          </div>

          {/* Segmented water meter */}
          <div className="mt-4 flex gap-1">
            {Array.from({ length: segments }).map((_, i) => (
              <div
                key={i}
                className={`h-8 flex-1 rounded-md transition-all duration-500 ${i < filled ? "bg-sky-500" : "bg-slate-100"}`}
                style={{ transitionDelay: `${i * 60}ms`, opacity: fill ? 1 : 0.4 }}
              />
            ))}
          </div>
          <div className="mt-3 flex items-baseline justify-between">
            <span className="text-sm text-slate-500">~ {data.estimatedLitersPerPlant} L / plant / day</span>
            <span className="text-sm font-bold text-sky-600">{data.needLevel}%</span>
          </div>
        </div>

        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3 text-sm">
            {[
              ["Crop", data.crop],
              ["Stage", data.growthStage],
              ["Soil", data.soilCondition],
              ["Method", data.irrigationMethod],
            ].map(([k, v]) => (
              <div key={k} className="rounded-lg bg-slate-50 px-3 py-2">
                <p className="text-xs text-slate-400">{k}</p>
                <p className="font-semibold text-slate-800">{v}</p>
              </div>
            ))}
          </div>
          <Disclosure label="Why this recommendation?">
            <ul className="space-y-2">
              {data.factors.map((f) => (
                <li key={f.label} className="flex items-start justify-between gap-3">
                  <span>
                    <span className="font-semibold text-slate-700">{f.label}:</span> {f.detail}
                  </span>
                  <span className="shrink-0 rounded-md bg-sky-50 px-2 py-0.5 text-xs font-semibold text-sky-700">{f.value}</span>
                </li>
              ))}
            </ul>
          </Disclosure>
        </div>
      </div>

      <p className="mt-4 text-xs text-slate-400">{data.note}</p>
    </Card>
  )
}
