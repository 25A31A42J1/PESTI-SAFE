import { ShieldCheck, Info, Leaf, Scissors, FlaskConical } from "lucide-react"
import { Card, Badge, Progress, Disclosure } from "../ui/Primitives.jsx"
import { treatments } from "../../data/demoData.js"

const icons = { bio: Leaf, cultural: Scissors, chemical: FlaskConical }
const toneRing = {
  brand: "ring-brand-200",
  amber: "ring-amber-200",
  rose: "ring-rose-200",
}

export default function TreatmentEngine() {
  return (
    <Card className="p-6 sm:p-8">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <Badge tone="brand" className="mb-2">
            <ShieldCheck className="h-3.5 w-3.5" /> Least-Harmful Decision Engine
          </Badge>
          <h3 className="font-display text-xl font-extrabold text-slate-900">Choose the safest effective option</h3>
          <p className="mt-1 text-slate-500">Start with the least harmful effective intervention. Escalate only if needed.</p>
        </div>
      </div>

      <div className="mt-6 rounded-xl bg-brand-50 px-4 py-3 text-sm font-semibold text-brand-700 flex items-center gap-2">
        <ShieldCheck className="h-5 w-5" />
        Recommended: start with option 1 (Biological) combined with option 2 (Cultural).
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        {treatments.map((tr, i) => {
          const Icon = icons[tr.id]
          return (
            <div
              key={tr.id}
              className={`relative flex flex-col rounded-2xl border border-slate-100 bg-white p-5 transition-all duration-300 hover:-translate-y-1 hover:shadow-card ${
                tr.rank === 1 ? `ring-1 ${toneRing[tr.tone]}` : ""
              }`}
              style={{ animation: `fade-in-up 0.5s ease-out ${i * 0.1}s both` }}
            >
              <div className="flex items-center justify-between">
                <span className="grid h-11 w-11 place-items-center rounded-xl bg-slate-50 text-slate-700">
                  <Icon className="h-5 w-5" />
                </span>
                <Badge tone={tr.tone}>#{tr.rank} · {tr.tag}</Badge>
              </div>
              <h4 className="mt-3 font-display font-bold text-slate-900">{tr.category}</h4>

              <div className="mt-3 grid grid-cols-2 gap-3 text-sm">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">Risk</p>
                  <p className={`font-bold ${tr.tone === "rose" ? "text-rose-600" : tr.tone === "amber" ? "text-amber-600" : "text-brand-600"}`}>
                    {tr.risk}
                  </p>
                </div>
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">Suitability</p>
                  <p className="font-bold text-slate-900">{tr.suitability}%</p>
                </div>
              </div>
              <Progress value={tr.suitability} tone={tr.tone === "rose" ? "rose" : tr.tone === "amber" ? "amber" : "brand"} className="mt-2" />

              <ul className="mt-4 space-y-1.5 text-sm text-slate-600">
                {tr.options.map((o) => (
                  <li key={o} className="flex items-start gap-2">
                    <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-brand-400" />
                    {o}
                  </li>
                ))}
              </ul>

              <div className="mt-4 space-y-2">
                <Disclosure label="Why it's recommended">
                  <p>{tr.why}</p>
                </Disclosure>
                <Disclosure label="Environmental considerations">
                  <p>{tr.environmental}</p>
                </Disclosure>
              </div>

              {tr.labelNotice && (
                <div className="mt-4 flex items-start gap-2 rounded-xl bg-rose-50 px-3 py-2.5 text-xs font-medium text-rose-700">
                  <Info className="mt-0.5 h-4 w-4 shrink-0" />
                  <span>{tr.labelNotice}</span>
                </div>
              )}
            </div>
          )
        })}
      </div>
    </Card>
  )
}
