import { CalendarCheck, Clock, CalendarDays, CheckCircle2 } from "lucide-react"
import { Card, Badge } from "../ui/Primitives.jsx"
import { actionPlan } from "../../data/demoData.js"

const phases = [
  { key: "today", title: "TODAY", icon: Clock, tone: "brand", items: actionPlan.today },
  { key: "next3Days", title: "NEXT 3 DAYS", icon: CalendarCheck, tone: "amber", items: actionPlan.next3Days },
  { key: "next7Days", title: "NEXT 7 DAYS", icon: CalendarDays, tone: "blue", items: actionPlan.next7Days },
]

const dot = { brand: "bg-brand-500", amber: "bg-amber-500", blue: "bg-sky-500" }

export default function ActionPlan() {
  return (
    <Card className="p-6 sm:p-8">
      <Badge tone="brand" className="mb-2">
        <CalendarCheck className="h-3.5 w-3.5" /> Step 4 · Act
      </Badge>
      <h3 className="font-display text-xl font-extrabold text-slate-900">Your crop protection plan</h3>
      <p className="mt-1 text-slate-500">A simple timeline so you know exactly what to do and when.</p>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        {phases.map((p, idx) => (
          <div
            key={p.key}
            className="relative rounded-2xl border border-slate-100 bg-slate-50/50 p-5"
            style={{ animation: `fade-in-up 0.5s ease-out ${idx * 0.1}s both` }}
          >
            <div className="flex items-center gap-2">
              <span className={`grid h-9 w-9 place-items-center rounded-xl text-white ${dot[p.tone]}`}>
                <p.icon className="h-5 w-5" />
              </span>
              <h4 className="font-display font-extrabold tracking-wide text-slate-900">{p.title}</h4>
            </div>
            <ul className="mt-4 space-y-3">
              {p.items.map((item) => (
                <li key={item} className="flex items-start gap-2.5 text-sm text-slate-600">
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-brand-500" />
                  {item}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </Card>
  )
}
