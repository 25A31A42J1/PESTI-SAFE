import { useRef, useState, useCallback, useEffect } from "react"
import { MoveHorizontal } from "lucide-react"

// Draggable before/after image comparison slider (mouse + touch + keyboard).
export default function CompareSlider({ beforeSrc, afterSrc, beforeLabel = "Before", afterLabel = "After" }) {
  const ref = useRef(null)
  const [pos, setPos] = useState(50)
  const dragging = useRef(false)

  const setFromClientX = useCallback((clientX) => {
    const rect = ref.current?.getBoundingClientRect()
    if (!rect) return
    const p = ((clientX - rect.left) / rect.width) * 100
    setPos(Math.max(0, Math.min(100, p)))
  }, [])

  useEffect(() => {
    const move = (e) => {
      if (!dragging.current) return
      const x = e.touches ? e.touches[0].clientX : e.clientX
      setFromClientX(x)
    }
    const up = () => (dragging.current = false)
    window.addEventListener("mousemove", move)
    window.addEventListener("touchmove", move)
    window.addEventListener("mouseup", up)
    window.addEventListener("touchend", up)
    return () => {
      window.removeEventListener("mousemove", move)
      window.removeEventListener("touchmove", move)
      window.removeEventListener("mouseup", up)
      window.removeEventListener("touchend", up)
    }
  }, [setFromClientX])

  return (
    <div
      ref={ref}
      className="relative aspect-[4/3] w-full select-none overflow-hidden rounded-2xl border border-slate-100"
      onMouseDown={(e) => {
        dragging.current = true
        setFromClientX(e.clientX)
      }}
      onTouchStart={(e) => {
        dragging.current = true
        setFromClientX(e.touches[0].clientX)
      }}
    >
      <img src={afterSrc} alt="After treatment" className="absolute inset-0 h-full w-full object-cover" draggable={false} />
      <span className="absolute right-3 top-3 rounded-lg bg-brand-600/90 px-2.5 py-1 text-xs font-bold text-white">
        {afterLabel}
      </span>

      <div className="absolute inset-0 overflow-hidden" style={{ width: `${pos}%` }}>
        <img
          src={beforeSrc}
          alt="Before treatment"
          className="absolute inset-0 h-full w-full object-cover"
          style={{ width: ref.current?.clientWidth || "100%", maxWidth: "none" }}
          draggable={false}
        />
        <span className="absolute left-3 top-3 rounded-lg bg-slate-900/80 px-2.5 py-1 text-xs font-bold text-white">
          {beforeLabel}
        </span>
      </div>

      {/* Handle */}
      <div className="absolute inset-y-0" style={{ left: `${pos}%` }}>
        <div className="absolute inset-y-0 -ml-px w-0.5 bg-white shadow-[0_0_8px_rgba(0,0,0,0.3)]" />
        <button
          aria-label="Drag to compare before and after"
          className="absolute top-1/2 -translate-x-1/2 -translate-y-1/2 grid h-10 w-10 place-items-center rounded-full bg-white text-brand-700 shadow-card"
          onKeyDown={(e) => {
            if (e.key === "ArrowLeft") setPos((p) => Math.max(0, p - 4))
            if (e.key === "ArrowRight") setPos((p) => Math.min(100, p + 4))
          }}
        >
          <MoveHorizontal className="h-5 w-5" />
        </button>
      </div>
    </div>
  )
}
