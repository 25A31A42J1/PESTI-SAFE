import { Link } from "react-router-dom"
import { Leaf, ShieldCheck } from "lucide-react"

export default function Footer() {
  return (
    <footer className="mt-20 border-t border-slate-100 bg-white">
      <div className="mx-auto max-w-7xl section-pad py-10">
        <div className="grid gap-8 md:grid-cols-4">
          <div className="md:col-span-2">
            <div className="flex items-center gap-2">
              <span className="grid h-8 w-8 place-items-center rounded-lg bg-brand-600 text-white">
                <Leaf className="h-4 w-4" />
              </span>
              <span className="font-display text-lg font-extrabold text-slate-900">
                Pesti<span className="text-brand-600">Safe</span>
              </span>
            </div>
            <p className="mt-3 max-w-sm text-sm text-slate-500 leading-relaxed">
              AI-powered sustainable crop protection. Detect, assess, decide, act, monitor and prevent — with the least
              harmful effective intervention first.
            </p>
            <div className="mt-4 inline-flex items-center gap-2 rounded-lg bg-brand-50 px-3 py-2 text-xs font-semibold text-brand-700">
              <ShieldCheck className="h-4 w-4" />
              Responsible AI · Decision support, not a replacement for experts
            </div>
          </div>
          <div>
            <h4 className="text-sm font-bold text-slate-900">Product</h4>
            <ul className="mt-3 space-y-2 text-sm text-slate-500">
              <li><Link to="/analyze" className="hover:text-brand-700">Crop Analysis</Link></li>
              <li><Link to="/recovery" className="hover:text-brand-700">Recovery Monitor</Link></li>
              <li><Link to="/risk-map" className="hover:text-brand-700">Crop Risk Map</Link></li>
              <li><Link to="/prevention" className="hover:text-brand-700">Prevention Center</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="text-sm font-bold text-slate-900">More</h4>
            <ul className="mt-3 space-y-2 text-sm text-slate-500">
              <li><Link to="/assistant" className="hover:text-brand-700">Voice Assistant</Link></li>
              <li><Link to="/settings" className="hover:text-brand-700">Settings & Language</Link></li>
              <li><Link to="/dashboard" className="hover:text-brand-700">Farmer Dashboard</Link></li>
            </ul>
          </div>
        </div>
        <div className="mt-10 border-t border-slate-100 pt-6 text-xs text-slate-400 flex flex-col sm:flex-row items-center justify-between gap-2">
          <p>© {new Date().getFullYear()} PestiSafe. Prototype for Smart India Hackathon.</p>
          <p>Weather, risk map and analysis shown are demo data.</p>
        </div>
      </div>
    </footer>
  )
}
