import { Sparkles } from "lucide-react"
import { useApp } from "../context/AppContext.jsx"

// Small floating indicator shown whenever demo data is being used.
export default function DemoBadge() {
  const { demoMode } = useApp()
  if (!demoMode) return null
  return (
    <div className="fixed bottom-4 left-4 z-50 animate-fade-in">
      <div className="flex items-center gap-2 rounded-full bg-slate-900/90 px-3.5 py-2 text-xs font-semibold text-white shadow-lg backdrop-blur">
        <span className="relative flex h-2 w-2">
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-brand-400 opacity-75" />
          <span className="relative inline-flex h-2 w-2 rounded-full bg-brand-400" />
        </span>
        <Sparkles className="h-3.5 w-3.5 text-brand-300" />
        Demo Mode active
      </div>
    </div>
  )
}
