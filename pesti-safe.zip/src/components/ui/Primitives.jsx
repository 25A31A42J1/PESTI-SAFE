import { useState } from "react"
import { ChevronDown } from "lucide-react"

export function Card({ className = "", children, ...props }) {
  return (
    <div className={`card ${className}`} {...props}>
      {children}
    </div>
  )
}

export function SectionTitle({ eyebrow, title, subtitle, center = false }) {
  return (
    <div className={`max-w-2xl ${center ? "mx-auto text-center" : ""}`}>
      {eyebrow && (
        <span className="chip bg-brand-50 text-brand-700 mb-3">{eyebrow}</span>
      )}
      <h2 className="font-display text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight text-balance">
        {title}
      </h2>
      {subtitle && <p className="mt-3 text-slate-500 leading-relaxed">{subtitle}</p>}
    </div>
  )
}

const toneMap = {
  brand: "bg-brand-50 text-brand-700",
  amber: "bg-amber-50 text-amber-700",
  rose: "bg-rose-50 text-rose-700",
  slate: "bg-slate-100 text-slate-600",
  blue: "bg-sky-50 text-sky-700",
}

export function Badge({ tone = "slate", children, className = "" }) {
  return <span className={`chip ${toneMap[tone]} ${className}`}>{children}</span>
}

export function Progress({ value, tone = "brand", className = "" }) {
  const colors = {
    brand: "bg-brand-500",
    amber: "bg-amber-500",
    rose: "bg-rose-500",
    blue: "bg-sky-500",
  }
  return (
    <div className={`h-2.5 w-full rounded-full bg-slate-100 overflow-hidden ${className}`}>
      <div
        className={`h-full rounded-full ${colors[tone]} transition-[width] duration-1000 ease-out`}
        style={{ width: `${Math.max(0, Math.min(100, value))}%` }}
      />
    </div>
  )
}

export function Disclosure({ label, children, defaultOpen = false }) {
  const [open, setOpen] = useState(defaultOpen)
  return (
    <div className="rounded-xl border border-slate-100 bg-slate-50/60">
      <button
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
        className="flex w-full items-center justify-between px-4 py-3 text-left font-semibold text-slate-700 hover:text-brand-700"
      >
        <span>{label}</span>
        <ChevronDown
          className={`h-4 w-4 shrink-0 transition-transform duration-300 ${open ? "rotate-180" : ""}`}
        />
      </button>
      <div
        className={`grid transition-all duration-300 ease-out ${
          open ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"
        }`}
      >
        <div className="overflow-hidden">
          <div className="px-4 pb-4 pt-0 text-sm text-slate-600">{children}</div>
        </div>
      </div>
    </div>
  )
}

export function Stat({ label, value, sub, tone = "slate" }) {
  const toneText = {
    slate: "text-slate-900",
    brand: "text-brand-600",
    amber: "text-amber-600",
    rose: "text-rose-600",
  }
  return (
    <div>
      <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">{label}</p>
      <p className={`mt-1 text-xl font-bold ${toneText[tone]}`}>{value}</p>
      {sub && <p className="text-xs text-slate-400">{sub}</p>}
    </div>
  )
}
