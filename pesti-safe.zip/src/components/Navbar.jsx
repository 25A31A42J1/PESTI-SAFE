import { useState } from "react"
import { NavLink, Link } from "react-router-dom"
import { Menu, X, Leaf, LayoutDashboard } from "lucide-react"
import { useTranslation } from "../context/AppContext.jsx"
import LanguageSelector from "./LanguageSelector.jsx"

const links = [
  { to: "/", key: "nav.home", end: true },
  { to: "/analyze", key: "nav.analyze" },
  { to: "/dashboard", key: "nav.myCrops" },
  { to: "/recovery", key: "nav.recovery" },
  { to: "/risk-map", key: "nav.riskMap" },
  { to: "/prevention", key: "nav.prevention" },
  { to: "/assistant", key: "nav.assistant" },
]

export default function Navbar() {
  const t = useTranslation()
  const [open, setOpen] = useState(false)

  const linkClass = ({ isActive }) =>
    `px-3 py-2 rounded-lg text-sm font-semibold transition-colors ${
      isActive ? "text-brand-700 bg-brand-50" : "text-slate-600 hover:text-brand-700 hover:bg-slate-50"
    }`

  return (
    <header className="sticky top-0 z-40 border-b border-slate-100 bg-white/80 backdrop-blur-md">
      <nav className="mx-auto flex max-w-7xl items-center justify-between gap-4 section-pad h-16">
        <Link to="/" className="flex items-center gap-2 shrink-0" onClick={() => setOpen(false)}>
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-brand-600 text-white shadow-glow">
            <Leaf className="h-5 w-5" />
          </span>
          <span className="font-display text-lg font-extrabold tracking-tight text-slate-900">
            Pesti<span className="text-brand-600">Safe</span>
          </span>
        </Link>

        <div className="hidden lg:flex items-center gap-1">
          {links.map((l) => (
            <NavLink key={l.to} to={l.to} end={l.end} className={linkClass}>
              {t(l.key)}
            </NavLink>
          ))}
        </div>

        <div className="hidden lg:flex items-center gap-2">
          <LanguageSelector />
          <Link to="/dashboard" className="btn-primary py-2 text-sm">
            <LayoutDashboard className="h-4 w-4" />
            {t("nav.dashboard")}
          </Link>
        </div>

        <button
          className="lg:hidden rounded-lg p-2 text-slate-700 hover:bg-slate-100"
          onClick={() => setOpen((o) => !o)}
          aria-label="Toggle navigation menu"
          aria-expanded={open}
        >
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </nav>

      {open && (
        <div className="lg:hidden border-t border-slate-100 bg-white animate-fade-in">
          <div className="section-pad py-3 space-y-1">
            {links.map((l) => (
              <NavLink
                key={l.to}
                to={l.to}
                end={l.end}
                onClick={() => setOpen(false)}
                className={({ isActive }) =>
                  `block rounded-lg px-3 py-2.5 font-semibold ${
                    isActive ? "text-brand-700 bg-brand-50" : "text-slate-700 hover:bg-slate-50"
                  }`
                }
              >
                {t(l.key)}
              </NavLink>
            ))}
            <div className="flex items-center justify-between gap-3 pt-3 border-t border-slate-100 mt-2">
              <LanguageSelector />
              <Link to="/dashboard" onClick={() => setOpen(false)} className="btn-primary py-2 text-sm flex-1">
                <LayoutDashboard className="h-4 w-4" />
                {t("nav.dashboard")}
              </Link>
            </div>
          </div>
        </div>
      )}
    </header>
  )
}
