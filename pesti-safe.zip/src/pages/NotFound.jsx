import { Link } from "react-router-dom"
import { Leaf, Home } from "lucide-react"

export default function NotFound() {
  return (
    <div className="mx-auto flex max-w-lg flex-col items-center justify-center px-6 py-24 text-center">
      <span className="grid h-16 w-16 place-items-center rounded-2xl bg-brand-50 text-brand-600">
        <Leaf className="h-8 w-8" />
      </span>
      <h1 className="mt-6 font-display text-4xl font-extrabold text-slate-900">Page not found</h1>
      <p className="mt-2 text-slate-500">The page you're looking for doesn't exist. Let's get you back on track.</p>
      <Link to="/" className="btn-primary mt-6">
        <Home className="h-4 w-4" /> Back to home
      </Link>
    </div>
  )
}
