import { useState } from "react"
import { XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Area, AreaChart } from "recharts"
import { Activity, TrendingUp, ArrowUpRight, Loader2, Upload, Sparkles } from "lucide-react"
import { useApp } from "../context/AppContext.jsx"
import { Card, Badge, SectionTitle } from "../components/ui/Primitives.jsx"
import CompareSlider from "../components/CompareSlider.jsx"
import { compareRecovery } from "../services/cropAnalysis.js"
import { recoveryData } from "../data/demoData.js"

export default function Recovery() {
  const { setDemoMode } = useApp()
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(false)

  const simulate = async () => {
    setDemoMode(true)
    setLoading(true)
    const r = await compareRecovery()
    setData(r)
    setLoading(false)
  }

  const view = data

  return (
    <div className="mx-auto max-w-5xl section-pad py-10 space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <SectionTitle
          eyebrow="Step 5 · Monitor"
          title="Before vs After recovery monitor"
          subtitle="Compare a follow-up photo against your first analysis to see whether the crop is responding to the plan."
        />
        <button onClick={simulate} disabled={loading} className="btn-primary">
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
          {loading ? "Comparing…" : "Simulate follow-up image"}
        </button>
      </div>

      {!view ? (
        <Card className="p-10 text-center">
          <div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-brand-50">
            <Upload className="h-8 w-8 text-brand-600" />
          </div>
          <h3 className="mt-4 font-display text-lg font-bold text-slate-900">Upload a second crop image</h3>
          <p className="mx-auto mt-1 max-w-md text-sm text-slate-500">
            After a few days of following your action plan, add a new photo. For the demo, use the button above to
            simulate a follow-up image and see the comparison instantly.
          </p>
          <div className="mt-6 grid gap-3 sm:grid-cols-2 max-w-lg mx-auto">
            <div className="rounded-xl border-2 border-dashed border-slate-200 p-6 text-sm text-slate-400">
              Before image (Day 1)
            </div>
            <div className="rounded-xl border-2 border-dashed border-slate-200 p-6 text-sm text-slate-400">
              After image (Day 7)
            </div>
          </div>
        </Card>
      ) : (
        <>
          <div className="grid gap-6 lg:grid-cols-5">
            <Card className="p-6 lg:col-span-3">
              <h3 className="font-display font-bold text-slate-900">Visual comparison</h3>
              <p className="text-sm text-slate-500">Drag the handle to compare Day 1 and Day 7.</p>
              <div className="mt-4">
                <CompareSlider
                  beforeSrc="/tomato-leaf-blight.png"
                  afterSrc="/tomato-leaf-recovered.png"
                  beforeLabel="Day 1"
                  afterLabel="Day 7"
                />
              </div>
            </Card>

            <div className="lg:col-span-2 space-y-6">
              <Card className="p-6">
                <div className="grid grid-cols-3 gap-3 text-center">
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">Before</p>
                    <p className="font-display text-2xl font-extrabold text-slate-900">{view.before}</p>
                  </div>
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">After</p>
                    <p className="font-display text-2xl font-extrabold text-brand-600">{view.after}</p>
                  </div>
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">Change</p>
                    <p className="font-display text-2xl font-extrabold text-brand-600">+{view.improvement}</p>
                  </div>
                </div>
                <div
                  className={`mt-4 flex items-center gap-2 rounded-xl px-4 py-3 text-sm font-semibold ${
                    view.status === "improving" ? "bg-brand-50 text-brand-700" : "bg-amber-50 text-amber-700"
                  }`}
                >
                  {view.status === "improving" ? <TrendingUp className="h-5 w-5" /> : <Activity className="h-5 w-5" />}
                  {view.status === "improving" ? "Improvement detected" : "Symptoms may be progressing"}
                </div>
              </Card>

              <Card className="p-6 bg-gradient-to-br from-brand-50 to-white">
                <div className="flex items-center gap-2 text-brand-700">
                  <ArrowUpRight className="h-5 w-5" />
                  <p className="font-semibold">{view.message}</p>
                </div>
                <p className="mt-3 text-xs text-slate-400">
                  Note: this is an image-based estimate, not scientific proof of recovery. Continue monitoring and
                  consult local guidance for important decisions.
                </p>
              </Card>
            </div>
          </div>

          <Card className="p-6 sm:p-8">
            <div className="flex items-center justify-between">
              <div>
                <Badge tone="brand" className="mb-2">
                  <Activity className="h-3.5 w-3.5" /> Crop Health Trend
                </Badge>
                <h3 className="font-display text-lg font-bold text-slate-900">Health score over 7 days</h3>
              </div>
            </div>
            <div className="mt-4 h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={view.timeline} margin={{ top: 10, right: 10, left: -18, bottom: 0 }}>
                  <defs>
                    <linearGradient id="rec" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#22c55e" stopOpacity={0.35} />
                      <stop offset="100%" stopColor="#22c55e" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                  <XAxis dataKey="day" tick={{ fontSize: 12, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
                  <YAxis domain={[40, 100]} tick={{ fontSize: 12, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
                  <Tooltip
                    contentStyle={{ borderRadius: 12, border: "1px solid #e2e8f0", fontSize: 13 }}
                    labelStyle={{ fontWeight: 700, color: "#0f172a" }}
                  />
                  <Area type="monotone" dataKey="score" stroke="#16a34a" strokeWidth={3} fill="url(#rec)" dot={{ r: 4, fill: "#16a34a" }} animationDuration={1200} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </Card>
        </>
      )}
    </div>
  )
}
