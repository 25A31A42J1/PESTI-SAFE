import { useState, useRef, useEffect } from "react"
import { Mic, MicOff, Send, Volume2, Bot, User, Sparkles, AlertTriangle } from "lucide-react"
import { useApp } from "../context/AppContext.jsx"
import { Card, Badge, SectionTitle } from "../components/ui/Primitives.jsx"
import LanguageSelector from "../components/LanguageSelector.jsx"
import { getAssistantReply, getSpeechRecognition, isSpeechSupported, speak, assistantStarters } from "../services/voiceService.js"

const greeting = {
  role: "assistant",
  text: "Namaste! I'm your PestiSafe assistant. Tell me what you're seeing on your crop and I'll help you decide what to do.",
}

export default function Assistant() {
  const { setDemoMode } = useApp()
  const [messages, setMessages] = useState([greeting])
  const [input, setInput] = useState("")
  const [listening, setListening] = useState(false)
  const [speechOn, setSpeechOn] = useState(true)
  const [supported] = useState(isSpeechSupported())
  const recRef = useRef(null)
  const endRef = useRef(null)

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const send = (text) => {
    const clean = text.trim()
    if (!clean) return
    setDemoMode(true)
    setInput("")
    setMessages((m) => {
      const next = [...m, { role: "user", text: clean }]
      const reply = getAssistantReply(clean, next)
      setTimeout(() => {
        setMessages((cur) => [...cur, { role: "assistant", text: reply }])
        if (speechOn) speak(reply)
      }, 500)
      return next
    })
  }

  const onKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing && e.keyCode !== 229) {
      e.preventDefault()
      send(input)
    }
  }

  const toggleMic = () => {
    if (!supported) return
    if (listening) {
      recRef.current?.stop()
      setListening(false)
      return
    }
    const rec = getSpeechRecognition()
    rec.continuous = false
    rec.interimResults = false
    rec.lang = "en-US"
    rec.onresult = (e) => send(e.results[0][0].transcript)
    rec.onend = () => setListening(false)
    rec.onerror = () => setListening(false)
    recRef.current = rec
    rec.start()
    setListening(true)
  }

  return (
    <div className="mx-auto max-w-3xl section-pad py-10">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <SectionTitle eyebrow="Voice Assistant" title="Talk to your crop advisor" />
        <LanguageSelector />
      </div>

      <Card className="mt-6 flex h-[560px] flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 px-5 py-3">
          <div className="flex items-center gap-3">
            <span className="relative grid h-10 w-10 place-items-center rounded-xl bg-brand-600 text-white">
              <Bot className="h-5 w-5" />
              <span className="absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-white bg-brand-400" />
            </span>
            <div>
              <p className="font-bold text-slate-900">PestiSafe Assistant</p>
              <p className="text-xs text-brand-600">Online · Agricultural support</p>
            </div>
          </div>
          <button
            onClick={() => setSpeechOn((s) => !s)}
            className={`btn text-xs px-3 py-2 ${speechOn ? "bg-brand-50 text-brand-700" : "bg-slate-100 text-slate-500"}`}
            aria-pressed={speechOn}
          >
            <Volume2 className="h-4 w-4" /> {speechOn ? "Voice on" : "Voice off"}
          </button>
        </div>

        {/* Messages */}
        <div className="flex-1 space-y-4 overflow-y-auto px-5 py-5">
          {messages.map((m, i) => (
            <div key={i} className={`flex items-end gap-2 ${m.role === "user" ? "flex-row-reverse" : ""}`}>
              <span
                className={`grid h-8 w-8 shrink-0 place-items-center rounded-full ${
                  m.role === "user" ? "bg-slate-200 text-slate-600" : "bg-brand-100 text-brand-700"
                }`}
              >
                {m.role === "user" ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
              </span>
              <div
                className={`max-w-[78%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed animate-fade-in ${
                  m.role === "user"
                    ? "rounded-br-md bg-brand-600 text-white"
                    : "rounded-bl-md bg-slate-100 text-slate-700"
                }`}
              >
                {m.text}
              </div>
            </div>
          ))}
          <div ref={endRef} />
        </div>

        {/* Starters */}
        {messages.length <= 1 && (
          <div className="flex flex-wrap gap-2 px-5 pb-2">
            {assistantStarters.map((s) => (
              <button
                key={s}
                onClick={() => send(s)}
                className="rounded-full border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-600 hover:border-brand-300 hover:text-brand-700"
              >
                {s}
              </button>
            ))}
          </div>
        )}

        {/* Input */}
        <div className="border-t border-slate-100 p-3">
          {!supported && (
            <p className="mb-2 flex items-center gap-1.5 px-1 text-xs text-amber-600">
              <AlertTriangle className="h-3.5 w-3.5" /> Voice input isn't supported here — type your message instead.
            </p>
          )}
          <div className="flex items-center gap-2">
            <button
              onClick={toggleMic}
              disabled={!supported}
              className={`btn h-11 w-11 shrink-0 rounded-xl p-0 ${
                listening ? "bg-rose-500 text-white animate-pulse" : "bg-slate-100 text-slate-600 hover:bg-slate-200"
              } disabled:opacity-40`}
              aria-label={listening ? "Stop listening" : "Start voice input"}
            >
              {listening ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
            </button>
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={onKeyDown}
              placeholder={listening ? "Listening…" : "Describe your crop problem…"}
              className="h-11 flex-1 rounded-xl border border-slate-200 bg-white px-4 text-sm text-slate-700 placeholder:text-slate-400 focus:border-brand-400"
            />
            <button onClick={() => send(input)} className="btn-primary h-11 w-11 rounded-xl p-0" aria-label="Send message">
              <Send className="h-5 w-5" />
            </button>
          </div>
        </div>
      </Card>

      <div className="mt-4 flex items-center justify-center gap-2 text-xs text-slate-400">
        <Sparkles className="h-3.5 w-3.5 text-brand-500" />
        Demo assistant with rule-based replies — ready to connect to a real language model later.
      </div>
    </div>
  )
}
