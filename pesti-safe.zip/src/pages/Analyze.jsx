import { useState, useRef, useEffect, useCallback } from "react"
import { useNavigate, useSearchParams } from "react-router-dom"
import {
  Upload,
  Camera,
  Mic,
  MicOff,
  ImageIcon,
  X,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  ScanSearch,
  Loader2,
  MapPin,
} from "lucide-react"
import { useApp, useTranslation } from "../context/AppContext.jsx"
import { Card, SectionTitle, Badge } from "../components/ui/Primitives.jsx"
import { cropOptions, growthStages } from "../data/demoData.js"
import { assessImageQuality, analyzeCrop } from "../services/cropAnalysis.js"
import { getSpeechRecognition, isSpeechSupported } from "../services/voiceService.js"

export default function Analyze() {
  const navigate = useNavigate()
  const t = useTranslation()
  const { setAnalysis, setDemoMode, demoMode } = useApp()
  const [params] = useSearchParams()

  const [image, setImage] = useState(null) // { url, isDemo }
  const [quality, setQuality] = useState(null) // { ok, status, message }
  const [checking, setChecking] = useState(false)
  const [crop, setCrop] = useState("")
  const [stage, setStage] = useState("")
  const [symptoms, setSymptoms] = useState("")
  const [location, setLocation] = useState("")
  const [dragOver, setDragOver] = useState(false)
  const [analyzing, setAnalyzing] = useState(false)
  const [error, setError] = useState("")
  const [listening, setListening] = useState(false)

  const fileRef = useRef(null)
  const cameraRef = useRef(null)
  const recognitionRef = useRef(null)

  const runDemo = useCallback(async () => {
    setDemoMode(true)
    setError("")
    setCrop("Tomato")
    setStage("Flowering")
    setSymptoms("Brown concentric spots on lower leaves, spreading slowly over the past week.")
    setLocation("Guntur, Andhra Pradesh")
    setImage({ url: "/tomato-leaf-blight.png", isDemo: true })
    setChecking(true)
    const q = await assessImageQuality(null, { forceGood: true })
    setQuality(q)
    setChecking(false)
  }, [setDemoMode])

  useEffect(() => {
    if (params.get("demo") === "1") runDemo()
  }, [params, runDemo])

  const handleFile = async (file) => {
    if (!file) return
    if (!file.type.startsWith("image/")) {
      setError("Please choose a valid image file (JPG or PNG).")
      return
    }
    setError("")
    const url = URL.createObjectURL(file)
    setImage({ url, isDemo: false })
    setDemoMode(false)
    setChecking(true)
    setQuality(null)
    try {
      const q = await assessImageQuality(file)
      setQuality(q)
    } catch {
      setError("Could not read the image. Please try another photo.")
    } finally {
      setChecking(false)
    }
  }

  const onDrop = (e) => {
    e.preventDefault()
    setDragOver(false)
    handleFile(e.dataTransfer.files?.[0])
  }

  const clearImage = () => {
    setImage(null)
    setQuality(null)
    setError("")
  }

  const toggleVoice = () => {
    if (!isSpeechSupported()) {
      setError("Voice input isn't supported in this browser. Please type your symptoms instead.")
      return
    }
    if (listening) {
      recognitionRef.current?.stop()
      setListening(false)
      return
    }
    const rec = getSpeechRecognition()
    rec.continuous = false
    rec.interimResults = false
    rec.lang = "en-US"
    rec.onresult = (e) => {
      const text = e.results[0][0].transcript
      setSymptoms((s) => (s ? `${s} ${text}` : text))
    }
    rec.onend = () => setListening(false)
    rec.onerror = () => setListening(false)
    recognitionRef.current = rec
    rec.start()
    setListening(true)
  }

  const canAnalyze = (image && quality?.ok) || (symptoms.trim().length > 8)

  const startAnalysis = async () => {
    setError("")
    if (!canAnalyze) {
      setError("Add a clear crop image or describe the symptoms (at least a sentence) to analyze.")
      return
    }
    setAnalyzing(true)
    try {
      const result = await analyzeCrop({
        crop,
        growthStage: stage,
        symptoms,
        location,
        demo: demoMode || image?.isDemo,
      })
      setAnalysis(result)
      navigate("/results")
    } catch (err) {
      setError(err.message || "AI analysis is temporarily unavailable. You can still use Demo Mode.")
      setAnalyzing(false)
    }
  }

  return (
    <div className="mx-auto max-w-6xl section-pad py-10">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <SectionTitle
          eyebrow="Step 1 · Detect"
          title="Analyze your crop"
          subtitle="Upload a photo or describe what you see. We'll assess the image and estimate the likely problem, severity and recovery potential."
        />
        <button onClick={runDemo} className="btn-secondary">
          <Sparkles className="h-4 w-4" />
          {t("cta.demo")}
        </button>
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-5">
        {/* Upload / preview */}
        <div className="lg:col-span-3 space-y-6">
          <Card className="p-6">
            <h3 className="font-display font-bold text-slate-900">Crop image</h3>
            {!image ? (
              <div
                onDragOver={(e) => {
                  e.preventDefault()
                  setDragOver(true)
                }}
                onDragLeave={() => setDragOver(false)}
                onDrop={onDrop}
                className={`mt-4 flex flex-col items-center justify-center rounded-2xl border-2 border-dashed p-10 text-center transition-colors ${
                  dragOver ? "border-brand-500 bg-brand-50" : "border-slate-200 bg-slate-50/60"
                }`}
              >
                <span className="grid h-14 w-14 place-items-center rounded-2xl bg-white shadow-soft">
                  <ImageIcon className="h-7 w-7 text-brand-600" />
                </span>
                <p className="mt-4 font-semibold text-slate-700">Drag & drop a leaf or plant photo</p>
                <p className="text-sm text-slate-400">JPG or PNG, clear and well-lit</p>
                <div className="mt-5 flex flex-wrap justify-center gap-3">
                  <button onClick={() => fileRef.current?.click()} className="btn-primary py-2.5">
                    <Upload className="h-4 w-4" /> Upload image
                  </button>
                  <button onClick={() => cameraRef.current?.click()} className="btn-secondary py-2.5">
                    <Camera className="h-4 w-4" /> Use camera
                  </button>
                </div>
                <input ref={fileRef} type="file" accept="image/*" hidden onChange={(e) => handleFile(e.target.files?.[0])} />
                <input
                  ref={cameraRef}
                  type="file"
                  accept="image/*"
                  capture="environment"
                  hidden
                  onChange={(e) => handleFile(e.target.files?.[0])}
                />
              </div>
            ) : (
              <div className="mt-4">
                <div className="relative overflow-hidden rounded-2xl border border-slate-100">
                  <img src={image.url} alt="Uploaded crop for analysis" className="h-64 w-full object-cover sm:h-80" />
                  <button
                    onClick={clearImage}
                    className="absolute right-3 top-3 grid h-9 w-9 place-items-center rounded-full bg-white/90 text-slate-700 shadow hover:bg-white"
                    aria-label="Remove image"
                  >
                    <X className="h-4 w-4" />
                  </button>
                  {image.isDemo && (
                    <div className="absolute left-3 top-3">
                      <Badge tone="brand" className="bg-white/90">
                        <Sparkles className="h-3.5 w-3.5" /> Demo sample
                      </Badge>
                    </div>
                  )}
                </div>

                {/* Image quality assessment */}
                <div className="mt-4">
                  {checking ? (
                    <div className="flex items-center gap-2 rounded-xl bg-slate-50 px-4 py-3 text-sm font-medium text-slate-500">
                      <Loader2 className="h-4 w-4 animate-spin text-brand-600" />
                      Assessing image quality…
                    </div>
                  ) : quality ? (
                    quality.ok ? (
                      <div className="flex items-center gap-2 rounded-xl bg-brand-50 px-4 py-3 text-sm font-semibold text-brand-700">
                        <CheckCircle2 className="h-5 w-5" /> {quality.message}
                      </div>
                    ) : (
                      <div className="flex items-start justify-between gap-3 rounded-xl bg-amber-50 px-4 py-3 text-sm font-semibold text-amber-700">
                        <span className="flex items-center gap-2">
                          <AlertTriangle className="h-5 w-5" /> {quality.message} — please upload another image.
                        </span>
                        <button onClick={() => fileRef.current?.click()} className="shrink-0 underline">
                          Retry
                        </button>
                      </div>
                    )
                  ) : null}
                </div>
              </div>
            )}
          </Card>

          {/* Symptom description + voice */}
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <h3 className="font-display font-bold text-slate-900">Describe the symptoms</h3>
              <button
                onClick={toggleVoice}
                className={`btn text-sm px-3 py-2 ${listening ? "bg-rose-50 text-rose-600" : "bg-slate-100 text-slate-600 hover:bg-slate-200"}`}
              >
                {listening ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
                {listening ? "Listening…" : "Voice"}
              </button>
            </div>
            <textarea
              value={symptoms}
              onChange={(e) => setSymptoms(e.target.value)}
              rows={3}
              placeholder="e.g. Brown spots on lower leaves, spreading over the past week…"
              className="mt-3 w-full resize-none rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 placeholder:text-slate-400 focus:border-brand-400"
            />
            <p className="mt-2 text-xs text-slate-400">
              Voice input uses your browser's speech recognition and falls back to text if unavailable.
            </p>
          </Card>
        </div>

        {/* Details + analyze */}
        <div className="lg:col-span-2 space-y-6">
          <Card className="p-6">
            <h3 className="font-display font-bold text-slate-900">Crop details</h3>
            <div className="mt-4 space-y-4">
              <Field label="Crop">
                <select value={crop} onChange={(e) => setCrop(e.target.value)} className="field">
                  <option value="">Select crop</option>
                  {cropOptions.map((c) => (
                    <option key={c}>{c}</option>
                  ))}
                </select>
              </Field>
              <Field label="Growth stage">
                <select value={stage} onChange={(e) => setStage(e.target.value)} className="field">
                  <option value="">Select stage</option>
                  {growthStages.map((s) => (
                    <option key={s}>{s}</option>
                  ))}
                </select>
              </Field>
              <Field label="Location (optional)">
                <div className="relative">
                  <MapPin className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                  <input
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder="Village / District"
                    className="field pl-9"
                  />
                </div>
              </Field>
            </div>
          </Card>

          {error && (
            <div className="flex items-start gap-2 rounded-xl bg-rose-50 px-4 py-3 text-sm font-medium text-rose-700">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <button onClick={startAnalysis} disabled={analyzing} className="btn-primary w-full text-base py-3.5">
            {analyzing ? (
              <>
                <Loader2 className="h-5 w-5 animate-spin" /> Analyzing…
              </>
            ) : (
              <>
                <ScanSearch className="h-5 w-5" /> Analyze Crop
              </>
            )}
          </button>
          <p className="text-center text-xs text-slate-400">
            No image? A written description works too. Or try the full demo case.
          </p>
        </div>
      </div>

      {/* Scanning overlay */}
      {analyzing && <ScanOverlay image={image?.url} />}

      <style>{`
        .field {
          width: 100%;
          border-radius: 0.75rem;
          border: 1px solid rgb(226 232 240);
          background: white;
          padding: 0.625rem 0.875rem;
          font-size: 0.875rem;
          color: rgb(51 65 85);
        }
        .field:focus { border-color: rgb(74 222 128); outline: none; }
      `}</style>
    </div>
  )
}

function Field({ label, children }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-400">{label}</span>
      {children}
    </label>
  )
}

function ScanOverlay({ image }) {
  const steps = ["Reading image", "Detecting patterns", "Estimating severity", "Comparing safe options"]
  const [step, setStep] = useState(0)
  useEffect(() => {
    const id = setInterval(() => setStep((s) => (s + 1) % steps.length), 650)
    return () => clearInterval(id)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm animate-fade-in">
      <Card className="w-[90%] max-w-sm p-6 text-center">
        <div className="relative mx-auto h-40 w-40 overflow-hidden rounded-2xl border border-brand-200">
          {image ? (
            <img src={image} alt="Analyzing crop" className="h-full w-full object-cover" />
          ) : (
            <div className="grid h-full w-full place-items-center bg-brand-50">
              <ScanSearch className="h-10 w-10 text-brand-500" />
            </div>
          )}
          <div className="absolute inset-0">
            <div className="absolute left-0 right-0 h-0.5 bg-brand-400 shadow-[0_0_12px_2px_rgba(34,197,94,0.7)] animate-scan" />
          </div>
          <div className="absolute inset-0 ring-1 ring-inset ring-brand-400/40" />
        </div>
        <p className="mt-5 font-display font-bold text-slate-900">AI scanning your crop</p>
        <p className="mt-1 text-sm text-brand-600 font-medium">{steps[step]}…</p>
        <div className="mt-4 flex justify-center gap-1.5">
          {steps.map((_, i) => (
            <span key={i} className={`h-1.5 w-6 rounded-full transition-colors ${i <= step ? "bg-brand-500" : "bg-slate-200"}`} />
          ))}
        </div>
      </Card>
    </div>
  )
}
