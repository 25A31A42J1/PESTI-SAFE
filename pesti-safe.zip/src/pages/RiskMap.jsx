import { useState } from "react"
import { MapPin, AlertTriangle, Info } from "lucide-react"
import { Card, Badge, SectionTitle } from "../components/ui/Primitives.jsx"
import { riskMapRegions } from "../data/demoData.js"

const levelColor = {
  low: { dot: "bg-brand-500", ring: "ring-brand-300", text: "text-brand-700", chip: "brand", label: "Low" },
  moderate: { dot: "bg-amber-500", ring: "ring-amber-300", text: "text-amber-700", chip: "amber", label: "Moderate" },
  high: { dot: "bg-rose-500", ring: "ring-rose-300", text: "text-rose-700", chip: "rose", label: "High" },
}

export default function RiskMap() {
  const [active, setActive] = useState(null)

  return (
    <div className="mx-auto max-w-6xl section-pad py-10 space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <SectionTitle
          eyebrow="Community surveillance"
          title="Crop risk map"
          subtitle="A preview of community-level agricultural disease surveillance — spot where problems are emerging nearby."
        />
        <Badge tone="slate">
          <Info className="h-3.5 w-3.5" /> Prototype / Demo Data
        </Badge>
      </div>

      <div className="grid gap-6 lg:grid-cols-5">
        {/* Map */}
        <Card className="p-4 sm:p-6 lg:col-span-3">
          <div className="relative aspect-[4/3] w-full overflow-hidden rounded-2xl bg-gradient-to-br from-brand-50 via-white to-sky-50 ring-1 ring-slate-100">
            {/* Decorative grid */}
            <svg className="absolute inset-0 h-full w-full opacity-40" aria-hidden="true">
              <defs>
                <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                  <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#e2e8f0" strokeWidth="1" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#grid)" />
            </svg>
            {/* Region hotspots */}
            {riskMapRegions.map((r) => {
              const c = levelColor[r.level]
              return (
                <button
                  key={r.id}
                  onClick={() => setActive(r)}
                  className="group absolute -translate-x-1/2 -translate-y-1/2"
                  style={{ left: `${r.x}%`, top: `${r.y}%` }}
                  aria-label={`${r.name}: ${c.label} risk`}
                >
                  <span className={`absolute inset-0 rounded-full ${c.dot} opacity-40 animate-pulse-ring`} />
                  <span className={`relative grid h-6 w-6 place-items-center rounded-full ${c.dot} text-white ring-4 ring-white shadow`}>
                    <MapPin className="h-3.5 w-3.5" />
                  </span>
                  <span className="pointer-events-none absolute left-1/2 top-full mt-1 -translate-x-1/2 whitespace-nowrap rounded-md bg-slate-900 px-2 py-1 text-[11px] font-semibold text-white opacity-0 transition-opacity group-hover:opacity-100">
                    {r.name} · {r.crop}
                  </span>
                </button>
              )
            })}
          </div>

          {/* Legend */}
          <div className="mt-4 flex flex-wrap items-center gap-4 text-sm">
            {Object.entries(levelColor).map(([k, c]) => (
              <span key={k} className="inline-flex items-center gap-2 text-slate-600">
                <span className={`h-3 w-3 rounded-full ${c.dot}`} /> {c.label} risk
              </span>
            ))}
          </div>
        </Card>

        {/* Reports list */}
        <div className="lg:col-span-2 space-y-4">
          {active && (
            <Card className={`p-5 ring-1 ${levelColor[active.level].ring} animate-scale-in`}>
              <div className="flex items-center justify-between">
                <h3 className="font-display font-bold text-slate-900">{active.name}</h3>
                <Badge tone={levelColor[active.level].chip}>{levelColor[active.level].label} risk</Badge>
              </div>
              <p className="mt-1 text-sm text-slate-500">{active.crop}</p>
              <p className={`mt-2 flex items-center gap-2 text-sm font-medium ${levelColor[active.level].text}`}>
                <AlertTriangle className="h-4 w-4" /> {active.note}
              </p>
            </Card>
          )}

          <Card className="p-6">
            <h3 className="font-display font-bold text-slate-900">Sample reports</h3>
            <div className="mt-4 space-y-2">
              {riskMapRegions.map((r) => {
                const c = levelColor[r.level]
                return (
                  <button
                    key={r.id}
                    onClick={() => setActive(r)}
                    className="flex w-full items-center gap-3 rounded-xl border border-slate-100 p-3 text-left transition-colors hover:bg-slate-50"
                  >
                    <span className={`h-3 w-3 shrink-0 rounded-full ${c.dot}`} />
                    <div className="min-w-0 flex-1">
                      <p className="font-semibold text-slate-800">{r.name} · {r.crop}</p>
                      <p className="truncate text-xs text-slate-400">{r.note}</p>
                    </div>
                    <Badge tone={c.chip}>{c.label}</Badge>
                  </button>
                )
              })}
            </div>
          </Card>
        </div>
      </div>

      <Card className="p-5 bg-slate-50/60">
        <p className="flex items-start gap-2 text-sm text-slate-500">
          <Info className="mt-0.5 h-4 w-4 shrink-0 text-slate-400" />
          This map uses prototype/demo data to illustrate future community-level agricultural disease surveillance.
          Real deployments would aggregate anonymized reports and official advisories.
        </p>
      </Card>
    </div>
  )
}
