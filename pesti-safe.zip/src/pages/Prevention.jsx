import { ScanEye, Bug, Sparkles, Repeat, CloudSun, Leaf, ShieldCheck } from "lucide-react"
import { Card, SectionTitle, Badge } from "../components/ui/Primitives.jsx"
import ResponsibleAI from "../components/ResponsibleAI.jsx"
import { preventionTips } from "../data/demoData.js"

const iconMap = { ScanEye, Bug, Sparkles, Repeat, CloudSun, Leaf }

export default function Prevention() {
  return (
    <div className="mx-auto max-w-6xl section-pad py-10 space-y-8">
      <SectionTitle
        center
        eyebrow="Step 6 · Prevent"
        title="Prevent future problems"
        subtitle="The cheapest, safest treatment is the one you never need. Build these habits to keep crops resilient season after season."
      />

      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {preventionTips.map((tip, i) => {
          const Icon = iconMap[tip.icon] || Leaf
          return (
            <Card
              key={tip.id}
              className="group p-6 transition-all duration-300 hover:-translate-y-1.5 hover:shadow-glow"
              style={{ animation: `fade-in-up 0.5s ease-out ${i * 0.07}s both` }}
            >
              <span className="grid h-12 w-12 place-items-center rounded-2xl bg-brand-50 text-brand-600 transition-transform duration-300 group-hover:scale-110">
                <Icon className="h-6 w-6" />
              </span>
              <h3 className="mt-4 font-display text-lg font-bold text-slate-900">{tip.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-slate-500">{tip.text}</p>
            </Card>
          )
        })}
      </div>

      <Card className="relative overflow-hidden p-8 bg-gradient-to-br from-brand-600 to-brand-700 text-white">
        <div className="absolute -right-8 -top-8 h-40 w-40 rounded-full bg-white/10 blur-2xl" />
        <div className="relative">
          <Badge className="bg-white/20 text-white mb-3">
            <ShieldCheck className="h-3.5 w-3.5" /> Sustainable by design
          </Badge>
          <h3 className="font-display text-xl font-extrabold">Favor biological & cultural controls first</h3>
          <p className="mt-2 max-w-2xl text-brand-50/90">
            Preserving beneficial insects, pollinators and soil life keeps your field's natural defenses strong — which
            means fewer outbreaks and less reliance on chemicals over time.
          </p>
        </div>
      </Card>

      <ResponsibleAI />
    </div>
  )
}
