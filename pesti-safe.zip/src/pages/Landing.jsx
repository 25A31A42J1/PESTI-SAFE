import { useNavigate } from "react-router-dom"
import {
  ScanSearch,
  GitCompareArrows,
  CloudSun,
  Activity,
  ArrowRight,
  Sparkles,
  ArrowDown,
  ShieldCheck,
  Leaf,
} from "lucide-react"
import { useApp, useTranslation } from "../context/AppContext.jsx"
import { Card, SectionTitle, Badge } from "../components/ui/Primitives.jsx"
import ResponsibleAI from "../components/ResponsibleAI.jsx"

const flowSteps = [
  { key: "flow.detect", desc: "Identify the likely problem" },
  { key: "flow.assess", desc: "Understand severity & risk" },
  { key: "flow.decide", desc: "Compare safer options" },
  { key: "flow.act", desc: "Follow an action plan" },
  { key: "flow.monitor", desc: "Track recovery" },
  { key: "flow.prevent", desc: "Stop it next season" },
]

const capabilities = [
  { icon: ScanSearch, titleKey: "landing.cap1.title", textKey: "landing.cap1.text", tone: "brand" },
  { icon: GitCompareArrows, titleKey: "landing.cap2.title", textKey: "landing.cap2.text", tone: "amber" },
  { icon: CloudSun, titleKey: "landing.cap3.title", textKey: "landing.cap3.text", tone: "blue" },
  { icon: Activity, titleKey: "landing.cap4.title", textKey: "landing.cap4.text", tone: "rose" },
]

const toneBg = {
  brand: "bg-brand-50 text-brand-600",
  amber: "bg-amber-50 text-amber-600",
  blue: "bg-sky-50 text-sky-600",
  rose: "bg-rose-50 text-rose-600",
}

export default function Landing() {
  const navigate = useNavigate()
  const t = useTranslation()
  const { setDemoMode } = useApp()

  const startDemo = () => {
    setDemoMode(true)
    navigate("/analyze?demo=1")
  }

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="mx-auto max-w-7xl section-pad pt-14 pb-16 sm:pt-20 sm:pb-24">
          <div className="grid items-center gap-12 lg:grid-cols-2">
            <div className="animate-fade-in-up">
              <Badge tone="brand" className="mb-5">
                <Sparkles className="h-3.5 w-3.5" />
                Detect → Assess → Decide → Act → Monitor → Prevent
              </Badge>
              <h1 className="font-display text-4xl sm:text-5xl xl:text-6xl font-extrabold leading-[1.05] tracking-tight text-slate-900 text-balance">
                {t("hero.title")}
              </h1>
              <p className="mt-5 max-w-xl text-lg text-slate-500 leading-relaxed">{t("hero.subtitle")}</p>
              <div className="mt-8 flex flex-col sm:flex-row gap-3">
                <button onClick={() => navigate("/analyze")} className="btn-primary text-base">
                  {t("cta.analyze")}
                  <ArrowRight className="h-5 w-5" />
                </button>
                <button onClick={startDemo} className="btn-secondary text-base">
                  <Sparkles className="h-5 w-5" />
                  {t("cta.demo")}
                </button>
              </div>
              <div className="mt-6 flex flex-wrap items-center gap-x-6 gap-y-2 text-sm text-slate-400">
                <span className="inline-flex items-center gap-1.5">
                  <ShieldCheck className="h-4 w-4 text-brand-500" /> Least-harm first
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <Leaf className="h-4 w-4 text-brand-500" /> Sustainable by design
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <CloudSun className="h-4 w-4 text-brand-500" /> Weather-aware decisions
                </span>
              </div>
            </div>

            <div className="relative animate-scale-in">
              <div className="absolute -inset-4 rounded-[2rem] bg-gradient-to-tr from-brand-200/40 to-transparent blur-2xl" />
              <div className="relative overflow-hidden rounded-3xl border border-white shadow-card">
                <img
                  src="/hero-crop.png"
                  alt="Healthy green crop field under natural light"
                  className="h-[360px] w-full object-cover sm:h-[440px]"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900/20 to-transparent" />
              </div>
              <Card className="absolute -bottom-6 -left-2 sm:left-4 w-52 p-4 animate-float">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">Crop Health</p>
                <div className="mt-1 flex items-end gap-2">
                  <span className="font-display text-3xl font-extrabold text-brand-600">62</span>
                  <span className="mb-1 text-xs text-slate-400">/ 100</span>
                </div>
                <div className="mt-2 h-2 rounded-full bg-slate-100">
                  <div className="h-full w-[62%] rounded-full bg-brand-500" />
                </div>
                <p className="mt-2 text-xs font-semibold text-amber-600">Moderate · Recovering</p>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Workflow */}
      <section className="mx-auto max-w-7xl section-pad py-6">
        <Card className="p-6 sm:p-10 bg-gradient-to-br from-white to-brand-50/40">
          <SectionTitle
            center
            eyebrow="The PestiSafe method"
            title="A full decision loop, not just a label"
            subtitle="Most tools stop at detection. PestiSafe walks the whole journey from problem to prevention."
          />
          <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
            {flowSteps.map((step, i) => (
              <div key={step.key} className="relative">
                <div
                  className="flex h-full flex-col items-center rounded-2xl border border-brand-100 bg-white p-4 text-center transition-transform duration-300 hover:-translate-y-1"
                  style={{ animation: `fade-in-up 0.5s ease-out ${i * 0.08}s both` }}
                >
                  <span className="grid h-9 w-9 place-items-center rounded-full bg-brand-600 text-sm font-bold text-white">
                    {i + 1}
                  </span>
                  <p className="mt-2 font-display font-bold text-slate-900">{t(step.key)}</p>
                  <p className="mt-1 text-xs text-slate-400">{step.desc}</p>
                </div>
                {i < flowSteps.length - 1 && (
                  <ArrowDown className="mx-auto my-1 h-4 w-4 text-brand-300 lg:hidden" />
                )}
              </div>
            ))}
          </div>
        </Card>
      </section>

      {/* Capabilities */}
      <section className="mx-auto max-w-7xl section-pad py-14">
        <SectionTitle center eyebrow="Capabilities" title={t("landing.capabilities")} />
        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {capabilities.map((c, i) => (
            <Card
              key={c.titleKey}
              className="group p-6 transition-all duration-300 hover:-translate-y-1.5 hover:shadow-glow"
              style={{ animation: `fade-in-up 0.5s ease-out ${i * 0.08}s both` }}
            >
              <span className={`grid h-12 w-12 place-items-center rounded-2xl ${toneBg[c.tone]} transition-transform duration-300 group-hover:scale-110`}>
                <c.icon className="h-6 w-6" />
              </span>
              <h3 className="mt-4 font-display text-lg font-bold text-slate-900">{t(c.titleKey)}</h3>
              <p className="mt-2 text-sm leading-relaxed text-slate-500">{t(c.textKey)}</p>
            </Card>
          ))}
        </div>
      </section>

      {/* Why different */}
      <section className="mx-auto max-w-7xl section-pad py-6">
        <div className="grid items-center gap-8 lg:grid-cols-2">
          <div>
            <SectionTitle
              eyebrow="The difference"
              title={t("landing.different")}
              subtitle="PestiSafe adds assessment, comparison, environmental context and monitoring around detection — so a diagnosis actually leads to a safe, effective decision."
            />
          </div>
          <div className="grid gap-4">
            <Card className="p-5 border-slate-200">
              <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">{t("landing.traditional")}</p>
              <div className="mt-3 flex flex-wrap items-center gap-2 text-sm font-semibold text-slate-500">
                <span className="rounded-lg bg-slate-100 px-3 py-1.5">Detect</span>
                <ArrowRight className="h-4 w-4 text-slate-300" />
                <span className="rounded-lg bg-slate-100 px-3 py-1.5">Recommend</span>
              </div>
            </Card>
            <Card className="p-5 ring-1 ring-brand-200">
              <p className="text-xs font-semibold uppercase tracking-wide text-brand-600">{t("landing.pestisafe")}</p>
              <div className="mt-3 flex flex-wrap items-center gap-2 text-sm font-semibold text-brand-700">
                {["Detect", "Assess", "Compare", "Decide", "Monitor", "Prevent"].map((s, i, arr) => (
                  <span key={s} className="inline-flex items-center gap-2">
                    <span className="rounded-lg bg-brand-50 px-3 py-1.5">{s}</span>
                    {i < arr.length - 1 && <ArrowRight className="h-4 w-4 text-brand-300" />}
                  </span>
                ))}
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Final message */}
      <section className="mx-auto max-w-7xl section-pad py-14">
        <Card className="relative overflow-hidden p-8 sm:p-12 bg-gradient-to-br from-brand-600 to-brand-700 text-white">
          <div className="absolute -right-10 -top-10 h-48 w-48 rounded-full bg-white/10 blur-2xl" />
          <div className="relative max-w-3xl">
            <Sparkles className="h-8 w-8 text-brand-200" />
            <p className="mt-4 font-display text-xl sm:text-2xl font-bold leading-relaxed text-balance">
              {t("landing.finalMessage")}
            </p>
            <div className="mt-8 flex flex-col sm:flex-row gap-3">
              <button
                onClick={startDemo}
                className="btn bg-white text-brand-700 px-6 py-3 hover:bg-brand-50 active:scale-[0.98]"
              >
                <Sparkles className="h-5 w-5" />
                {t("cta.demo")}
              </button>
              <button
                onClick={() => navigate("/analyze")}
                className="btn border border-white/40 text-white px-6 py-3 hover:bg-white/10 active:scale-[0.98]"
              >
                {t("cta.analyze")}
                <ArrowRight className="h-5 w-5" />
              </button>
            </div>
          </div>
        </Card>
      </section>

      {/* Responsible AI */}
      <section className="mx-auto max-w-7xl section-pad pb-6">
        <ResponsibleAI />
      </section>
    </div>
  )
}
