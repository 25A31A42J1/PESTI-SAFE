import { Check, Globe, Sparkles, ShieldCheck, Bell, Sun } from "lucide-react"
import { useApp } from "../context/AppContext.jsx"
import { Card, SectionTitle } from "../components/ui/Primitives.jsx"
import ResponsibleAI from "../components/ResponsibleAI.jsx"

export default function Settings() {
  const { lang, setLang, languages, demoMode, setDemoMode } = useApp()

  return (
    <div className="mx-auto max-w-4xl section-pad py-10 space-y-6">
      <SectionTitle eyebrow="Settings" title="Language & preferences" subtitle="Choose your language and manage demo settings." />

      {/* Language */}
      <Card className="p-6">
        <div className="flex items-center gap-2">
          <Globe className="h-5 w-5 text-brand-600" />
          <h3 className="font-display font-bold text-slate-900">Language</h3>
        </div>
        <p className="mt-1 text-sm text-slate-500">
          UI text is centralized so more languages can be added easily. Headline strings are localized; the rest fall back to English.
        </p>
        <div className="mt-4 grid gap-3 sm:grid-cols-3">
          {languages.map((l) => (
            <button
              key={l.code}
              onClick={() => setLang(l.code)}
              className={`flex items-center justify-between rounded-xl border p-4 text-left transition-all ${
                lang === l.code ? "border-brand-300 bg-brand-50 ring-1 ring-brand-200" : "border-slate-200 hover:border-brand-200"
              }`}
            >
              <div>
                <p className="font-bold text-slate-900">{l.native}</p>
                <p className="text-xs text-slate-400">{l.label}</p>
              </div>
              {lang === l.code && (
                <span className="grid h-6 w-6 place-items-center rounded-full bg-brand-600 text-white">
                  <Check className="h-4 w-4" />
                </span>
              )}
            </button>
          ))}
        </div>
      </Card>

      {/* Preferences */}
      <Card className="p-6">
        <h3 className="font-display font-bold text-slate-900">Preferences</h3>
        <div className="mt-4 space-y-3">
          <ToggleRow
            icon={Sparkles}
            title="Demo Mode"
            desc="Use curated sample data across the app for demonstrations."
            checked={demoMode}
            onChange={() => setDemoMode((d) => !d)}
          />
          <ToggleRow icon={Bell} title="Risk alerts" desc="Notify me about nearby crop disease reports." checked disabled />
          <ToggleRow icon={Sun} title="Weather-aware advice" desc="Factor local conditions into treatment timing." checked disabled />
        </div>
        <div className="mt-4 flex items-center gap-2 rounded-xl bg-slate-50 px-4 py-3 text-xs text-slate-500">
          <ShieldCheck className="h-4 w-4 text-brand-500" />
          No sensitive farmer information is stored. API keys are never exposed in the frontend — configure them via environment variables.
        </div>
      </Card>

      <ResponsibleAI />
    </div>
  )
}

function ToggleRow({ icon: Icon, title, desc, checked, onChange, disabled }) {
  return (
    <div className="flex items-center justify-between rounded-xl border border-slate-100 p-4">
      <div className="flex items-center gap-3">
        <span className="grid h-10 w-10 place-items-center rounded-xl bg-slate-50 text-slate-600">
          <Icon className="h-5 w-5" />
        </span>
        <div>
          <p className="font-semibold text-slate-800">{title}</p>
          <p className="text-xs text-slate-400">{desc}</p>
        </div>
      </div>
      <button
        onClick={onChange}
        disabled={disabled}
        role="switch"
        aria-checked={checked}
        aria-label={title}
        className={`relative h-6 w-11 shrink-0 rounded-full transition-colors disabled:opacity-60 ${checked ? "bg-brand-500" : "bg-slate-300"}`}
      >
        <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all ${checked ? "left-[22px]" : "left-0.5"}`} />
      </button>
    </div>
  )
}
