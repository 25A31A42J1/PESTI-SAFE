import { useNavigate } from "react-router-dom"
import {
  Activity,
  ArrowRight,
  Gauge,
  TrendingUp,
  Radio,
  Clock,
  ScanSearch,
} from "lucide-react"
import { useApp } from "../context/AppContext.jsx"
import { Card, Badge, Disclosure, Progress } from "../components/ui/Primitives.jsx"
import HealthRing from "../components/HealthRing.jsx"
import ResponsibleAI from "../components/ResponsibleAI.jsx"
import TreatmentEngine from "../components/sections/TreatmentEngine.jsx"
import Environmental from "../components/sections/Environmental.jsx"
import WaterGuidance from "../components/sections/WaterGuidance.jsx"
import ActionPlan from "../components/sections/ActionPlan.jsx"
import { demoCrop, scoreFactors } from "../data/demoData.js"

export default function Results() {
  const navigate = useNavigate()
  const { analysis } = useApp()
  // Fall back to demo case if the user navigated here directly.
  const data = analysis || { ...demoCrop, scoreFactors }
  const factors = data.scoreFactors || scoreFactors

  const metrics = [
    { icon: Gauge, label: "Severity", value: data.severity, tone: "amber" },
    { icon: TrendingUp, label: "Recovery Potential", value: data.recoveryPotential, tone: "brand" },
    { icon: Radio, label: "Risk of Spread", value: data.risk, tone: "rose" },
    { icon: Clock, label: "Urgency", value: data.urgency, tone: "slate" },
  ]

  return (
    <div className="mx-auto max-w-6xl section-pad py-10 space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <Badge tone="brand" className="mb-2">
            <ScanSearch className="h-3.5 w-3.5" /> Step 2 · Assess
          </Badge>
          <h1 className="font-display text-2xl sm:text-3xl font-extrabold text-slate-900">Analysis results</h1>
          <p className="mt-1 text-slate-500">Estimates only — wording reflects AI uncertainty, not certainty.</p>
        </div>
        <button onClick={() => navigate("/analyze")} className="btn-ghost">
          <ScanSearch className="h-4 w-4" /> New analysis
        </button>
      </div>

      {/* Top summary */}
      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="p-6 flex flex-col items-center justify-center text-center lg:col-span-1">
          <HealthRing score={data.healthScore} severity={data.severity} />
          <p className="mt-4 text-sm font-semibold text-slate-500">Crop Health Score</p>
        </Card>

        <Card className="p-6 lg:col-span-2">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">Possible problem</p>
              <h2 className="font-display text-2xl font-extrabold text-slate-900">{data.problem}</h2>
              <p className="text-sm text-slate-500">
                {data.crop} · {data.growthStage} {data.pathogen ? `· ${data.pathogen}` : ""}
              </p>
            </div>
            <div className="text-right">
              <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">AI Confidence</p>
              <p className="font-display text-2xl font-extrabold text-brand-600">{data.confidence}%</p>
            </div>
          </div>
          <Progress value={data.confidence} className="mt-3" />

          <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
            {metrics.map((m) => (
              <div key={m.label} className="rounded-xl border border-slate-100 bg-slate-50/60 p-3">
                <m.icon
                  className={`h-5 w-5 ${
                    m.tone === "brand" ? "text-brand-500" : m.tone === "amber" ? "text-amber-500" : m.tone === "rose" ? "text-rose-500" : "text-slate-400"
                  }`}
                />
                <p className="mt-2 text-xs font-semibold uppercase tracking-wide text-slate-400">{m.label}</p>
                <p className="mt-0.5 text-sm font-bold text-slate-900">{m.value}</p>
              </div>
            ))}
          </div>

          <div className="mt-5">
            <Disclosure label="Why this score?">
              <p className="mb-3 text-slate-500">
                The estimated health score combines several observed and environmental factors:
              </p>
              <ul className="space-y-3">
                {factors.map((f) => (
                  <li key={f.label} className="rounded-lg bg-white border border-slate-100 p-3">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-slate-700">{f.label}</span>
                      <span className="text-xs font-bold text-rose-500">{f.impact}</span>
                    </div>
                    <p className="text-xs text-slate-500">{f.detail}</p>
                    <div className="mt-2 flex items-center gap-2">
                      <span className="text-[11px] font-semibold text-slate-400">Weight: {f.weight}</span>
                      <Progress value={Math.abs(f.impact) * 4} tone="amber" className="h-1.5" />
                    </div>
                  </li>
                ))}
              </ul>
            </Disclosure>
          </div>
        </Card>
      </div>

      {/* Step 3: Decide */}
      <TreatmentEngine />

      {/* Environmental + Water */}
      <div className="grid gap-6">
        <Environmental />
        <WaterGuidance />
      </div>

      {/* Step 4: Act */}
      <ActionPlan />

      {/* Next: monitor */}
      <Card className="relative overflow-hidden p-6 sm:p-8 bg-gradient-to-br from-brand-600 to-brand-700 text-white">
        <div className="absolute -right-8 -top-8 h-40 w-40 rounded-full bg-white/10 blur-2xl" />
        <div className="relative flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <Badge className="bg-white/20 text-white mb-2">
              <Activity className="h-3.5 w-3.5" /> Step 5 · Monitor
            </Badge>
            <h3 className="font-display text-xl font-extrabold">Track whether your crop is recovering</h3>
            <p className="mt-1 text-brand-50/90 max-w-md">
              Upload a follow-up photo in a few days and compare health scores side by side.
            </p>
          </div>
          <button
            onClick={() => navigate("/recovery")}
            className="btn bg-white text-brand-700 px-6 py-3 hover:bg-brand-50 active:scale-[0.98]"
          >
            Open Recovery Monitor
            <ArrowRight className="h-5 w-5" />
          </button>
        </div>
      </Card>

      <ResponsibleAI />
    </div>
  )
}
