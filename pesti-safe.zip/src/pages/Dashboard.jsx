import { Link } from "react-router-dom"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts"
import {
  Sprout,
  Activity,
  AlertTriangle,
  TrendingUp,
  TrendingDown,
  Minus,
  History,
  Bell,
  ArrowRight,
  ScanSearch,
} from "lucide-react"
import { Card, Badge, SectionTitle, Progress } from "../components/ui/Primitives.jsx"
import { dashboardCrops, recentAnalyses, riskAlerts } from "../data/demoData.js"

const statusTone = {
  Improving: "brand",
  Healthy: "brand",
  "Needs Attention": "rose",
}

const trendIcon = { up: TrendingUp, down: TrendingDown, flat: Minus }

export default function Dashboard() {
  const avg = Math.round(dashboardCrops.reduce((a, c) => a + c.score, 0) / dashboardCrops.length)
  const active = dashboardCrops.filter((c) => c.status === "Needs Attention").length
  const improving = dashboardCrops.filter((c) => c.status === "Improving").length

  const summary = [
    { icon: Sprout, label: "My Crops", value: dashboardCrops.length, sub: "Tracked plots", tone: "brand" },
    { icon: Activity, label: "Avg Crop Health", value: `${avg}/100`, sub: "Across all crops", tone: "blue" },
    { icon: AlertTriangle, label: "Active Problems", value: active, sub: "Need attention", tone: "rose" },
    { icon: TrendingUp, label: "Recovery Progress", value: improving, sub: "Crops improving", tone: "amber" },
  ]

  const barColor = (s) => (s >= 80 ? "#16a34a" : s >= 60 ? "#22c55e" : s >= 40 ? "#f59e0b" : "#ef4444")

  return (
    <div className="mx-auto max-w-6xl section-pad py-10 space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <SectionTitle eyebrow="Farmer Dashboard" title="Your crops at a glance" />
        <Link to="/analyze" className="btn-primary">
          <ScanSearch className="h-4 w-4" /> New analysis
        </Link>
      </div>

      {/* Summary cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {summary.map((s, i) => (
          <Card key={s.label} className="p-5" style={{ animation: `fade-in-up 0.5s ease-out ${i * 0.06}s both` }}>
            <div className="flex items-center justify-between">
              <span
                className={`grid h-10 w-10 place-items-center rounded-xl ${
                  s.tone === "brand" ? "bg-brand-50 text-brand-600" : s.tone === "blue" ? "bg-sky-50 text-sky-600" : s.tone === "rose" ? "bg-rose-50 text-rose-600" : "bg-amber-50 text-amber-600"
                }`}
              >
                <s.icon className="h-5 w-5" />
              </span>
            </div>
            <p className="mt-3 font-display text-2xl font-extrabold text-slate-900">{s.value}</p>
            <p className="text-sm font-semibold text-slate-600">{s.label}</p>
            <p className="text-xs text-slate-400">{s.sub}</p>
          </Card>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-5">
        {/* Crop list */}
        <div className="lg:col-span-3 space-y-4">
          <Card className="p-6">
            <h3 className="font-display font-bold text-slate-900">My crops</h3>
            <div className="mt-4 space-y-3">
              {dashboardCrops.map((c) => {
                const Trend = trendIcon[c.trend]
                return (
                  <div key={c.id} className="flex items-center gap-4 rounded-xl border border-slate-100 p-4 transition-colors hover:bg-slate-50">
                    <span className="grid h-11 w-11 place-items-center rounded-xl bg-brand-50 text-brand-600">
                      <Sprout className="h-5 w-5" />
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <p className="font-bold text-slate-900">{c.name}</p>
                        <span className="text-xs text-slate-400">{c.variety}</span>
                      </div>
                      <p className="truncate text-sm text-slate-500">{c.problem}</p>
                    </div>
                    <div className="hidden sm:block w-28">
                      <Progress value={c.score} tone={c.score >= 60 ? "brand" : "rose"} />
                    </div>
                    <div className="text-right">
                      <p className="font-display font-extrabold text-slate-900">{c.score}</p>
                      <Badge tone={statusTone[c.status]} className="mt-0.5">
                        <Trend className="h-3 w-3" /> {c.status}
                      </Badge>
                    </div>
                  </div>
                )
              })}
            </div>
          </Card>

          <Card className="p-6">
            <h3 className="font-display font-bold text-slate-900">Crop health comparison</h3>
            <div className="mt-4 h-56">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={dashboardCrops} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <XAxis dataKey="name" tick={{ fontSize: 12, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
                  <YAxis domain={[0, 100]} tick={{ fontSize: 12, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
                  <Tooltip
                    cursor={{ fill: "#f8fafc" }}
                    contentStyle={{ borderRadius: 12, border: "1px solid #e2e8f0", fontSize: 13 }}
                  />
                  <Bar dataKey="score" radius={[8, 8, 0, 0]} animationDuration={1000}>
                    {dashboardCrops.map((c) => (
                      <Cell key={c.id} fill={barColor(c.score)} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Card>
        </div>

        {/* Right column */}
        <div className="lg:col-span-2 space-y-4">
          <Card className="p-6">
            <div className="flex items-center gap-2">
              <Bell className="h-5 w-5 text-rose-500" />
              <h3 className="font-display font-bold text-slate-900">Risk alerts</h3>
            </div>
            <div className="mt-4 space-y-3">
              {riskAlerts.map((a) => (
                <div
                  key={a.id}
                  className={`rounded-xl p-4 ${a.level === "high" ? "bg-rose-50" : "bg-amber-50"}`}
                >
                  <p className={`font-semibold ${a.level === "high" ? "text-rose-700" : "text-amber-700"}`}>{a.title}</p>
                  <p className="mt-0.5 text-sm text-slate-600">{a.detail}</p>
                </div>
              ))}
              <Link to="/risk-map" className="flex items-center justify-between rounded-xl border border-slate-100 px-4 py-3 text-sm font-semibold text-brand-700 hover:bg-brand-50">
                View crop risk map <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center gap-2">
              <History className="h-5 w-5 text-slate-500" />
              <h3 className="font-display font-bold text-slate-900">Recent analyses</h3>
            </div>
            <div className="mt-4 space-y-2">
              {recentAnalyses.map((r) => (
                <div key={r.id} className="flex items-center justify-between rounded-lg px-3 py-2.5 hover:bg-slate-50">
                  <div>
                    <p className="text-sm font-semibold text-slate-800">{r.crop}</p>
                    <p className="text-xs text-slate-400">{r.problem} · {r.date}</p>
                  </div>
                  <Badge tone={r.severity === "None" ? "brand" : r.severity === "Low" ? "blue" : "amber"}>
                    {r.confidence}%
                  </Badge>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  )
}
