// Centralized translation dictionary.
// UI strings live here — components read them via the useTranslation() hook,
// so no language string is hardcoded inside a component.
// Non-English entries fall back to English keys that are not yet localized.

export const languages = [
  { code: "en", label: "English", native: "English" },
  { code: "te", label: "Telugu", native: "తెలుగు" },
  { code: "hi", label: "Hindi", native: "हिन्दी" },
  { code: "ta", label: "Tamil", native: "தமிழ்" },
  { code: "kn", label: "Kannada", native: "ಕನ್ನಡ" },
  { code: "ml", label: "Malayalam", native: "മലയാളം" },
  { code: "mr", label: "Marathi", native: "मराठी" },
]

const en = {
  "app.name": "PestiSafe",
  "app.tagline": "AI-Powered Sustainable Crop Protection",

  "nav.home": "Home",
  "nav.analyze": "Analyze",
  "nav.myCrops": "My Crops",
  "nav.recovery": "Recovery",
  "nav.riskMap": "Risk Map",
  "nav.prevention": "Prevention",
  "nav.assistant": "Assistant",
  "nav.language": "Language",
  "nav.dashboard": "Dashboard",

  "cta.analyze": "Analyze My Crop",
  "cta.demo": "Try Demo",

  "hero.title": "Smarter Crop Protection. Less Harm. Better Harvests.",
  "hero.subtitle":
    "PestiSafe uses AI-powered crop analysis and sustainable decision support to help farmers identify problems, choose safer interventions, and monitor crop recovery.",

  "landing.capabilities": "What PestiSafe Does",
  "landing.cap1.title": "AI Crop Diagnosis",
  "landing.cap1.text": "Estimate the likely problem, confidence, and severity from a photo or symptom description.",
  "landing.cap2.title": "Least-Harmful Decision Engine",
  "landing.cap2.text": "Compare biological, cultural, and chemical options — starting with the safest effective one.",
  "landing.cap3.title": "Environmental Intelligence",
  "landing.cap3.text": "Factor in weather, humidity, and rain before you act to avoid wasted or harmful applications.",
  "landing.cap4.title": "Crop Recovery Monitoring",
  "landing.cap4.text": "Track health over days with before/after comparison so you know if the plan is working.",

  "landing.different": "Why PestiSafe is Different",
  "landing.traditional": "Traditional systems",
  "landing.pestisafe": "PestiSafe",

  "landing.finalMessage":
    "PestiSafe doesn't just identify the problem. It helps farmers understand severity, choose safer interventions, consider environmental conditions, take action, and measure whether the crop is recovering.",

  "flow.detect": "Detect",
  "flow.assess": "Assess",
  "flow.decide": "Decide",
  "flow.act": "Act",
  "flow.monitor": "Monitor",
  "flow.prevent": "Prevent",

  "common.whyScore": "Why this score?",
  "common.whyRecommendation": "Why this recommendation?",
  "common.demoMode": "Demo Mode",
  "common.mockData": "Prototype / Demo Data",
  "common.confidence": "AI Confidence",

  "responsible.title": "Responsible AI",
  "responsible.main": "PestiSafe is an AI decision-support tool, not a replacement for agricultural experts.",
}

// Translated headline strings for prominent UI. Missing keys fall back to English.
const overrides = {
  te: {
    "hero.title": "తెలివైన పంట రక్షణ. తక్కువ హాని. మెరుగైన దిగుబడి.",
    "cta.analyze": "నా పంటను విశ్లేషించండి",
    "cta.demo": "డెమో చూడండి",
    "nav.home": "హోమ్",
    "nav.analyze": "విశ్లేషణ",
    "nav.dashboard": "డాష్‌బోర్డ్",
    "responsible.main": "పెస్టీసేఫ్ ఒక AI నిర్ణయ-సహాయ సాధనం, వ్యవసాయ నిపుణులకు ప్రత్యామ్నాయం కాదు.",
  },
  hi: {
    "hero.title": "स्मार्ट फसल सुरक्षा। कम नुकसान। बेहतर पैदावार।",
    "cta.analyze": "मेरी फसल का विश्लेषण करें",
    "cta.demo": "डेमो आज़माएँ",
    "nav.home": "होम",
    "nav.analyze": "विश्लेषण",
    "nav.dashboard": "डैशबोर्ड",
    "responsible.main": "पेस्टीसेफ एक AI निर्णय-सहायता उपकरण है, कृषि विशेषज्ञों का विकल्प नहीं।",
  },
  ta: {
    "hero.title": "புத்திசாலித்தனமான பயிர் பாதுகாப்பு. குறைந்த தீங்கு. சிறந்த அறுவடை.",
    "cta.analyze": "என் பயிரை பகுப்பாய்வு செய்",
    "cta.demo": "டெமோவை முயற்சி செய்",
    "nav.dashboard": "டாஷ்போர்டு",
  },
  kn: {
    "hero.title": "ಸ್ಮಾರ್ಟ್ ಬೆಳೆ ರಕ್ಷಣೆ. ಕಡಿಮೆ ಹಾನಿ. ಉತ್ತಮ ಫಸಲು.",
    "cta.analyze": "ನನ್ನ ಬೆಳೆ ವಿಶ್ಲೇಷಿಸಿ",
    "cta.demo": "ಡೆಮೊ ಪ್ರಯತ್ನಿಸಿ",
    "nav.dashboard": "ಡ್ಯಾಶ್‌ಬೋರ್ಡ್",
  },
  ml: {
    "hero.title": "സ്മാർട്ട് വിള സംരക്ഷണം. കുറഞ്ഞ ദോഷം. മികച്ച വിളവ്.",
    "cta.analyze": "എന്റെ വിള വിശകലനം ചെയ്യുക",
    "cta.demo": "ഡെമോ പരീക്ഷിക്കുക",
    "nav.dashboard": "ഡാഷ്‌ബോർഡ്",
  },
  mr: {
    "hero.title": "स्मार्ट पीक संरक्षण. कमी नुकसान. चांगले उत्पादन.",
    "cta.analyze": "माझ्या पिकाचे विश्लेषण करा",
    "cta.demo": "डेमो पहा",
    "nav.dashboard": "डॅशबोर्ड",
  },
}

export const translations = Object.fromEntries(
  languages.map(({ code }) => [code, { ...en, ...(overrides[code] || {}) }]),
)
