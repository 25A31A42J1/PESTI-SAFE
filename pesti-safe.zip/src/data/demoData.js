// Centralized mock/demo data for PestiSafe.
// Every value here is DEMO data — replace with real API responses later.
// Keeping it isolated makes swapping in real services trivial.

export const demoCrop = {
  crop: "Tomato",
  variety: "Roma",
  growthStage: "Flowering",
  problem: "Early Blight",
  pathogen: "Alternaria solani (fungal)",
  confidence: 87,
  healthScore: 62,
  severity: "Moderate",
  recoveryPotential: "High",
  risk: "Medium",
  urgency: "Act within 48 hours",
  location: "Guntur, Andhra Pradesh",
  imageQuality: "good",
}

// Factors that explain the health score (used by "Why this score?")
export const scoreFactors = [
  { label: "Visible symptoms", detail: "Concentric brown lesions on lower leaves", impact: -18, weight: "High" },
  { label: "Affected area", detail: "~20% of foliage shows spotting", impact: -12, weight: "Medium" },
  { label: "Symptom severity", detail: "Lesions moderate, not yet on fruit", impact: -8, weight: "Medium" },
  { label: "Crop stage", detail: "Flowering — sensitive but recoverable", impact: -5, weight: "Low" },
  { label: "Environmental conditions", detail: "High humidity favors fungal spread", impact: -7, weight: "Medium" },
]

export const weatherData = {
  isMock: true,
  temperature: 28,
  humidity: 78,
  rainProbability: 70,
  wind: "Moderate",
  windSpeed: 14,
  soilCondition: "Moist",
  uvIndex: 6,
  decision:
    "Rain is likely within 24 hours. Reassess environmental conditions before applying any treatment — wet foliage reduces effectiveness and can increase runoff.",
  status: "caution", // good | caution | avoid
}

export const waterData = {
  crop: "Tomato",
  growthStage: "Flowering",
  soilCondition: "Moist",
  irrigationMethod: "Drip",
  estimatedLitersPerPlant: 2.4,
  needLevel: 68, // 0-100 for meter
  recommendation: "Moderate irrigation",
  factors: [
    { label: "Crop water demand", detail: "Tomato at flowering has elevated demand", value: "High" },
    { label: "Soil moisture", detail: "Soil currently moist, reduce volume", value: "Moderate" },
    { label: "Irrigation efficiency", detail: "Drip delivers water efficiently to roots", value: "Efficient" },
    { label: "Rain forecast", detail: "70% rain probability — delay heavy watering", value: "Delay" },
  ],
  note: "This is a demo estimate based on typical crop coefficients, not an exact agronomic prescription.",
}

export const treatments = [
  {
    id: "bio",
    rank: 1,
    category: "Biological / Natural Control",
    tag: "Least harm first",
    tone: "brand",
    risk: "Low",
    suitability: 82,
    options: ["Copper-based bio-fungicide (organic-approved)", "Neem oil foliar spray", "Bacillus subtilis biocontrol"],
    why: "Targets the fungal pathogen with minimal impact on beneficial insects, soil life, and pollinators. Well suited to moderate early-stage infections.",
    environmental: "Low toxicity to bees and aquatic life. Short pre-harvest interval. Preferred near water sources.",
  },
  {
    id: "cultural",
    rank: 2,
    category: "Cultural / Mechanical Control",
    tag: "Supports every plan",
    tone: "amber",
    risk: "Very Low",
    suitability: 74,
    options: [
      "Remove and destroy infected lower leaves",
      "Improve airflow and reduce leaf wetness",
      "Mulch to prevent soil splash",
      "Avoid overhead irrigation",
    ],
    why: "Reduces the source of infection and slows spread without any chemical input. Strengthens the effect of biological control.",
    environmental: "Zero chemical footprint. Always recommended alongside other methods.",
  },
  {
    id: "chemical",
    rank: 3,
    category: "Chemical Control",
    tag: "Only if needed",
    tone: "rose",
    risk: "Higher",
    suitability: 61,
    options: ["Registered protectant fungicide (see product label)"],
    why: "Consider only if the infection continues to progress after lower-risk measures. Reserve for higher-severity situations.",
    environmental:
      "May affect non-target organisms and water bodies. Rotate active ingredients to prevent resistance.",
    labelNotice:
      "PestiSafe does not provide pesticide dosages. For any regulated product, follow the product label and your local agricultural authority's guidance.",
  },
]

export const actionPlan = {
  today: [
    "Inspect affected plants and mark infected leaves",
    "Apply the recommended low-risk (biological) intervention",
    "Remove severely infected lower leaves and dispose away from the field",
    "Observe environmental conditions before spraying",
  ],
  next3Days: [
    "Monitor symptoms daily and photograph affected areas",
    "Check whether the affected area is increasing",
    "Reassess crop health score",
    "Hold chemical treatment unless symptoms worsen",
  ],
  next7Days: [
    "Upload another crop image for comparison",
    "Compare recovery using the Before/After monitor",
    "Update the treatment decision based on progress",
    "Review prevention practices for the next cycle",
  ],
}

export const recoveryData = {
  before: 62,
  after: 78,
  improvement: 16,
  status: "improving", // improving | progressing
  timeline: [
    { day: "Day 1", score: 62 },
    { day: "Day 2", score: 64 },
    { day: "Day 3", score: 69 },
    { day: "Day 5", score: 73 },
    { day: "Day 7", score: 78 },
  ],
  message: "Improvement detected — affected area is shrinking and new growth appears healthy.",
}

export const dashboardCrops = [
  { id: 1, name: "Tomato", variety: "Roma", score: 78, status: "Improving", problem: "Early Blight (recovering)", trend: "up" },
  { id: 2, name: "Rice", variety: "BPT-5204", score: 91, status: "Healthy", problem: "None detected", trend: "flat" },
  { id: 3, name: "Chilli", variety: "Guntur", score: 54, status: "Needs Attention", problem: "Leaf Curl (suspected)", trend: "down" },
  { id: 4, name: "Cotton", variety: "Bt-Hybrid", score: 83, status: "Healthy", problem: "None detected", trend: "up" },
]

export const recentAnalyses = [
  { id: 1, crop: "Tomato", problem: "Early Blight", confidence: 87, date: "Today", severity: "Moderate" },
  { id: 2, crop: "Chilli", problem: "Leaf Curl", confidence: 71, date: "2 days ago", severity: "Moderate" },
  { id: 3, crop: "Rice", problem: "Healthy", confidence: 94, date: "5 days ago", severity: "None" },
  { id: 4, crop: "Cotton", problem: "Aphid presence", confidence: 68, date: "1 week ago", severity: "Low" },
]

export const riskAlerts = [
  { id: 1, level: "high", title: "Early Blight rising nearby", detail: "Increased reports within 12 km — inspect tomato plots." },
  { id: 2, level: "moderate", title: "High humidity window", detail: "Fungal-friendly conditions expected for 3 days." },
]

export const riskMapRegions = [
  { id: 1, name: "Guntur", crop: "Tomato", level: "high", x: 46, y: 58, note: "Disease reports increasing" },
  { id: 2, name: "Krishna", crop: "Rice", level: "low", x: 62, y: 40, note: "Low risk" },
  { id: 3, name: "Prakasam", crop: "Chilli", level: "moderate", x: 38, y: 74, note: "Moderate risk" },
  { id: 4, name: "Kurnool", crop: "Cotton", level: "low", x: 26, y: 52, note: "Low risk" },
  { id: 5, name: "West Godavari", crop: "Rice", level: "moderate", x: 74, y: 30, note: "Watch for blast" },
  { id: 6, name: "Anantapur", crop: "Groundnut", level: "high", x: 18, y: 70, note: "Leaf spot spreading" },
]

export const preventionTips = [
  { id: 1, icon: "ScanEye", title: "Regular Crop Monitoring", text: "Scan plants every 3–4 days to catch problems while they are small and cheap to control." },
  { id: 2, icon: "Bug", title: "Early Symptom Detection", text: "Photograph unusual spots or wilting immediately — early action needs the least intervention." },
  { id: 3, icon: "Sparkles", title: "Field Hygiene", text: "Remove crop debris and infected material to break the disease cycle between seasons." },
  { id: 4, icon: "Repeat", title: "Crop Rotation", text: "Rotate families each season to starve soil-borne pathogens and pests of their host." },
  { id: 5, icon: "CloudSun", title: "Environmental Monitoring", text: "Track humidity and rainfall — many diseases spike in warm, wet windows." },
  { id: 6, icon: "Leaf", title: "Sustainable Pest Management", text: "Favor biological and cultural controls, preserving beneficial insects and soil health." },
]

export const cropOptions = ["Tomato", "Rice", "Chilli", "Cotton", "Wheat", "Groundnut", "Maize", "Sugarcane", "Potato", "Onion"]
export const growthStages = ["Seedling", "Vegetative", "Flowering", "Fruiting", "Maturity"]
export const irrigationMethods = ["Drip", "Sprinkler", "Furrow", "Flood", "Manual"]
export const soilConditions = ["Dry", "Moist", "Wet", "Waterlogged"]
